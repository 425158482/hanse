<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

think\Route::get("/","index/index/index");
think\Route::get(":title","index/common/index");
think\Route::get("/address/:title","index/index/index");

think\Route::get("/navs/:title","index/common/index");
think\Route::get("/show/:title/:id","index/common/show");
think\Route::post("/form/:id","index/form/form");
think\Route::post("/search/form/","index/search/index");

$route = db("nav")->select();
foreach ($route as $k=>$v){
    think\Route::get("{$v['url_static']}/:id","index/common/show");
}




think\Route::get("/wap/:title","wap/index/index");
think\Route::post("/wap/search/","wap/search/index");
think\Route::get("/wap/:title","wap/common/index");
think\Route::get("/wap/:title/:id","wap/common/show");
think\Route::post("/wap/:id","wap/form/form");


think\Route::get("/wap/index","wap/index/index");
foreach ($route as $k=>$v){
    think\Route::get("/wap/{$v['url_static']}/:id","wap/common/show");
}