<?php
namespace app\index\controller;

use think\Controller;
use think\Config;
class Base extends Controller
{
    protected function _initialize()
    {
        $time = date("Y年m月d日",time());
        $res = db("system")->where("create_time",$time)->find();
        if($res){
            db("system")->where("id",$res["id"])->update(["number"=>$res["number"]+1]);
        }else{
            db("system")->insert(["number"=>1,"create_time"=>$time]);
        }
        $fileadd = CONF_PATH.DS.'extra'.DS.'site.php';//配置文件地址
        Config::load($fileadd, '', 'site');//加载配置文件
        $slide = Config::get('map_auto','site');
        if($slide){//检测是否自动跳转
            if(isMobile()){
                $this->redirect(url('/wap/index'),302);
            }
        }

    }
}
