<?php
namespace app\index\controller;

use think\Controller;

class Index extends Base
{
    public function index($title=false)
    {
        $this->assign(["title"=>$title]);
        return $this->fetch();
    }
}
