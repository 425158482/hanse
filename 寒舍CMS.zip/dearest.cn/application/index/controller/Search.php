<?php
namespace app\index\controller;

use think\Controller;
use think\Db;

class Search extends Base
{

    /**
     * $id = 栏目id
     **/
    public function index()
    {
        $key = input("post.");
        $data = Db::name("content")
            ->alias("a")
            ->join("nav","nav.id=a.pid")
            ->field("a.*,nav.url_static as url")
            ->where("a.title","like","%".$key['key']."%")
            ->select();
        foreach ($data as $k=>$v){
            $data[$k]["url"]="/".$v["url"]."/".$v["id"].".html";
        }
        $this->assign([
            'content'=>$data,
            'title'=>false
        ]);
        return $this->fetch("index/search");
    }

}
