<?php
namespace app\wap\controller;

use think\Controller;

class Index extends Controller
{
    public function index($title=false)
    {
        $this->assign(["title"=>$title]);
        return $this->fetch();
    }
}
