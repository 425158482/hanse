<?php
namespace app\wap\controller;

use think\Controller;
use think\Db;

class Form extends Controller
{
    public function form($id)
    {
        $data = input("post.");
        $token = request()->session()['__token__'];
        if($token==$data["__token__"]){
            if(!captcha_check($data["captcha"])){
                $this->error("验证码验证失败");
            };
            $form = Db::name("form")->where("id",$id)->find();//查询表单名称
            $field = Db::name("field_form")->where("fid",$id)->select();//表单字段
            $table = "form_".$form["bname"];
            foreach ($field as $k=>$v){
                if($v["space"]==1){
                    if($data[$v["field"]]==""||$data[$v["field"]]==null){
                        $this->error("必填项不能为空");
                    }
                }
            }
            $res["conid"] = Db::name($table)->strict(false)->insertGetId($data);
            $res["fid"] = $id;
            $res["ip"] = request()->ip();
            $res["static"]=1;
            $res["create_time"] = time();
            $msg = Db::name("formcon")->strict(false)->insertGetId($res);
            if($msg){
                $this->success("保存成功");
            }else{
                $this->error("保存失败");
            }
        }else{
            $this->error("令牌验证失败");
        }

    }
}
