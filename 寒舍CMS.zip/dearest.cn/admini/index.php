<?php
//后台入口文件
header('location:/admini/index/index');
?>