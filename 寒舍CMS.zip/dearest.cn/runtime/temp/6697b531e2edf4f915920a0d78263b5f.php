<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:64:"D:\phpstudy_pro\WWW\dearest.cn\/template/pc/index\list_jszc.html";i:1570684303;s:67:"D:\phpstudy_pro\WWW\dearest.cn\template\pc\index\public_header.html";i:1570680120;s:67:"D:\phpstudy_pro\WWW\dearest.cn\template\pc\index\public_footer.html";i:1570679555;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="format-detection" content="telephone=yes">
  <title><?php $navcon = db("nav")->where("id",$navid)->find();$address = input("title");$etitle = explode("_",$address); if(count($etitle)==2): $address = $etitle[0]; endif; $dq = db("address")->where("etitle",$address)->find(); if($dq): $navcon["name"]=$dq["title"].$navcon["name"]; $navcon["url"]="/navs/".$dq["etitle"]."_".$navcon["url_static"].".html"; else: $navcon["url"]="/".$navcon["url_static"].".html"; endif; ?><?php echo $navcon['name']; ?> - <?php $fileadd = CONF_PATH.DS."extra".DS."site.php"; \think\Config::load($fileadd, "", "site"); $titlew = input("title"); $etitle = explode("_",$titlew); if(($titlew)): if(count($etitle)==2): $titles = $etitle[0]; $configarr = \think\Config::get("f_seo_title","site"); $address = db("address")->where("etitle",$titles)->find(); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $titles = $title; $address = db("address")->where("etitle",$titles)->find(); if(($address)): $configarr = \think\Config::get("f_seo_title","site"); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $configarr = \think\Config::get("seo_title","site"); ?><?php echo $configarr; endif; endif; else: $configarr = \think\Config::get("seo_title","site"); ?><?php echo $configarr; endif; ?></title>
  <meta name="keywords" content="<?php $fileadd = CONF_PATH.DS."extra".DS."site.php"; \think\Config::load($fileadd, "", "site"); $titlew = input("title"); $etitle = explode("_",$titlew); if(($titlew)): if(count($etitle)==2): $titles = $etitle[0]; $configarr = \think\Config::get("f_seo_keywords","site"); $address = db("address")->where("etitle",$titles)->find(); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $titles = $title; $address = db("address")->where("etitle",$titles)->find(); if(($address)): $configarr = \think\Config::get("f_seo_keywords","site"); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $configarr = \think\Config::get("seo_keywords","site"); ?><?php echo $configarr; endif; endif; else: $configarr = \think\Config::get("seo_keywords","site"); ?><?php echo $configarr; endif; ?>">
  <meta name="description" content="<?php $fileadd = CONF_PATH.DS."extra".DS."site.php"; \think\Config::load($fileadd, "", "site"); $titlew = input("title"); $etitle = explode("_",$titlew); if(($titlew)): if(count($etitle)==2): $titles = $etitle[0]; $configarr = \think\Config::get("f_seo_description","site"); $address = db("address")->where("etitle",$titles)->find(); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $titles = $title; $address = db("address")->where("etitle",$titles)->find(); if(($address)): $configarr = \think\Config::get("f_seo_description","site"); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $configarr = \think\Config::get("seo_description","site"); ?><?php echo $configarr; endif; endif; else: $configarr = \think\Config::get("seo_description","site"); ?><?php echo $configarr; endif; ?>">
  <meta name="renderer" content="webkit">
<!--ico-->
<link rel="stylesheet" type="text/css" href="/template/pc/index/css/base.css" />
<link rel="stylesheet" type="text/css" href="/template/pc/index/css/animate.min.css" />
<link rel="stylesheet" type="text/css" href="/template/pc/index/css/owl.carousel.css" />
<link rel="stylesheet" type="text/css" href="/template/pc/index/css/style.css" />
<link rel="stylesheet" type="text/css" href="/template/pc/index/css/responsive.css" />
<script src="/template/pc/index/js/jquery-1.11.0.min.js"></script>
<script src="/template/pc/index/js/wow.min_1.js"></script>
<script src="/template/pc/index/js/owl.carousel.min.js"></script>
<script src="/template/pc/index/js/page.js"></script>
</head>
<body>

<div class="header">
    <div class="rowFluid">
        <div class="span2 col-md-12">
            <div class="logo">
                <a href="/" title="返回首页">
                    <img src="/uploads/20191010/b2aad0e34b511de03d30f714cc11534f.png" alt="响应式网络建设设计公司网站模板(自适应移动设备)" />
                </a>
            </div>
        </div>
        <div class="span8">
            <div class="mobileMenuBtn"><span class="span1"></span><span class="span2"></span><span class="span3"></span></div>
            <div class="mobileMenuBtn_shad"></div>
            <div class="header_menu">
                <ul id="menu">
                    <?php $navid = isset($navid) ? $navid : 0;  $topnav = isset($topnav) ? $topnav : 0;  ?>
                    <li><a href="/"  <?php if(($navid==0)): ?>class="active"<?php endif; ?> title="首页">首页</a></li>
                    <?php $data = db("nav")->where("pid",0)->where("show",1)->limit(10)->order("sort","asc")->select();$address = input("title");$etitle = explode("_",$address); foreach($data as $k=>$nav): if(count($etitle)==2): $address = $etitle[0]; endif; $dq = db("address")->where("etitle",$address)->find(); if(($dq)): $nav["name"]=$dq["title"].$nav["name"]; $nav["url"]="/navs/".$dq["etitle"]."_".$nav["url_static"].".html"; else: $nav["url"]="/".$nav["url_static"].".html"; endif; ?>
                        <li><a href="<?php echo $nav['url']; ?>" <?php if($navid==$nav["id"]||$topnav==$nav['id']): ?>class="active"<?php endif; ?> title="<?php echo $nav['name']; ?>"><?php echo $nav['name']; ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <div class="span2"> </div>
    </div>
</div>
<div class="aside">
    <ul>
        <li class="consulting"> <a href="#this"  title="合作"><img src="/template/pc/index/images/057.png" alt="合作" />合作</a> </li>
        <li class="consulting">
            <a href="#this" title="建站在线客服">
                <span></span>
                <span></span>
                <span></span>
                <img src="/template/pc/index/images/059.png" class="img1" alt="建站在线客服" />
                <img src="/template/pc/index/images/061.png" class="img2" alt="建站在线客服" />咨询
            </a>
        </li>
        <li >
            <yunu:type typeid='92'>
                <a href="">
                    <img src="/template/pc/index/images/060.png" alt="建站帮助中心" />帮助
                </a>
            </yunu:type>
        </li>
    </ul>
</div>
<!--yinchang-->
<div class="consulting_box">
    <div class="title">
        <div class="title_t1">RELATEED CONSULTING</div>
        <div class="title_t2">相关咨询 </div>
    </div>
    <div class="consulting_type">
        <div class="consulting_type_title">选择下列产品马上在线沟通</div>
        <ul>
            <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" title="响应式建站咨询"> <img src="/template/pc/index/images/062.png" class="img1" alt="网站建设" /><img src="/template/pc/index/images/063.png" class="img2" alt="响应式网站咨询" />建站咨询 </a> </li>
            <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" title="建站平台加盟咨询"> <img src="/template/pc/index/images/062.png" class="img1" alt="建站平台" /><img src="/template/pc/index/images/063.png" class="img2" alt="建站平台代理咨询" />加盟咨询 </a> </li>
            <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=&site=qq&menu=yes" title="设计咨询"> <img src="/template/pc/index/images/062.png" class="img1" alt="设计咨询" /><img src="/template/pc/index/images/063.png" class="img2" alt="设计咨询" />设计咨询 </a> </li>
        </ul>
        <div class="time">服务时间：9:30-18:00</div>
    </div>
    <div class="problem">
        <div class="problem_title">你可能遇到了下面的问题</div>
        <ul>
            <?php $nav = db("nav")->where("id",10)->find();$model = db("models")->where("id",$nav["model"])->find();$table = "new_".$model["bname"];$res = db("nav")->where("id",10)->select();$navids = numbernav($res);$data = db("content")->where("pid","in",$navids)->where("reco","in","0,1")->limit(5)->order("create_Time desc")->select();$address = input("title");$etitle = explode("_",$address);if(count($etitle)==2): $address = $etitle[0]; endif; foreach($data as $k=>$list): $dq = db("address")->where("etitle",$address)->find();if($dq): $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["title"]=$dq["title"].$list["title"];$list["url"] = "/show/".$dq["etitle"]."_".$nav["url_static"]."/".$list["id"].".html";else: $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["url"] = "/".$nav["url_static"]."/".$list["id"].".html";endif; ?>
                <li><span></span><a href="<?php echo $list['url']; ?>" title="<?php echo $list['title']; ?>"><?php echo $list['title']; ?></a></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <div class="close"> <img src="/template/pc/index/images/close.png" alt="关闭右侧工具栏" /> </div>
</div>

<div class="page">
<div class="rowFluid">
<div class="span12">
<div class="main">
<div class="z_banner support_z_banner">
  <div class="rowFluid">
    <div class="span12">
      <div class="container">
        <h3 class="z_banner_title">技术支持</h3>
        <div class="z_banner_input">
          <form  name="formsearch" action="/search/form/" method="post">
            <input type="text" name="key" id="search-keyword" value="" placeholder="请输入关键词...." />
            <button type="submit" class="search-submit" style="border: 0"> <img src="/template/pc/index/images/search.png" alt="查询"></button>
          </form>
        </div>
      </div>
      <ul class="platform_advantage_bg_z">
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
      </ul>
    </div>
  </div>
</div>
<div class="support_type">
  <div class="rowFluid">
    <div class="span12">
      <div class="container">
        <div class="support_type_content">
          <?php $f = topnav($topnav);$sub = db("nav")->where("pid",$f)->where("show",1)->limit(10)->order("sort","asc")->select();$address = input("title");$etitle = explode("_",$address); if(count($etitle)==2): $address = $etitle[0]; endif; foreach($sub as $k=>$navsub): $dq = db("address")->where("etitle",$address)->find(); if($dq): $navsub["name"]=$dq["title"].$navsub["name"]; $navsub["url"]="/navs/".$dq["etitle"]."_".$navsub["url_static"].".html"; else: $navsub["url"]="/".$navsub["url_static"].".html"; endif; ?>
            <div class="span2 col-xs-4"> <a href="<?php echo $navsub['url']; ?>" class="support_type_list normal <?php if($topnav==$navsub['id']){ ?>currrl<?php } ?>" title="<?php echo $navsub['name']; ?>"><?php echo $navsub['name']; ?></a> </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="technical_support">
<div class="rowFluid">
  <div class="span12">
    <div class="container">
      <div class="technical_support_content">
        <div class="span3 col-sm-12 wow fadeInLeft">
          <div class="technical_support_list">
            <div class="technical_support_type">
              <div class="title">技术支持分类<span><img src="/template/pc/index/images/page_right1.png" alt="" /></span></div>
              <ul id="left_menu">
                <?php $f = topnav($topnav);$sub = db("nav")->where("pid",$f)->where("show",1)->limit(10)->order("sort","asc")->select();$address = input("title");$etitle = explode("_",$address); if(count($etitle)==2): $address = $etitle[0]; endif; foreach($sub as $k=>$navsub): $dq = db("address")->where("etitle",$address)->find(); if($dq): $navsub["name"]=$dq["title"].$navsub["name"]; $navsub["url"]="/navs/".$dq["etitle"]."_".$navsub["url_static"].".html"; else: $navsub["url"]="/".$navsub["url_static"].".html"; endif; ?>
                  <li class=""> <a href="<?php echo $navsub['url']; ?>" title="<?php echo $navsub['name']; ?>"><?php echo $navsub['name']; ?></a> </li>
                <?php endforeach; ?>
              </ul>
            </div>
          </div>
        </div>
        <div class="span9 col-sm-12 wow fadeInRight">
          <div class="technical_support_list">
            <div class="technical_support_box">
              <div class="title">
                <?php $navcon = db("nav")->where("id",$navid)->find();$address = input("title");$etitle = explode("_",$address); if(count($etitle)==2): $address = $etitle[0]; endif; $dq = db("address")->where("etitle",$address)->find(); if($dq): $navcon["name"]=$dq["title"].$navcon["name"]; $navcon["url"]="/navs/".$dq["etitle"]."_".$navcon["url_static"].".html"; else: $navcon["url"]="/".$navcon["url_static"].".html"; endif; ?>
                  <?php echo $navcon['name']; ?>
                
              </div>
              <ul>
                <?php $nav = db("nav")->where("id",$navid)->find();$model = db("models")->where("id",$nav["model"])->find();$table = "new_".$model["bname"];$res = db("nav")->where("id",$navid)->select();$navids = numbernav($res);$data = db("content")->where("pid","in",$navids)->where("reco","in","0,1")->order("create_Time desc")->paginate(20);$page = $data->render();$address = input("title");$etitle = explode("_",$address);if(count($etitle)==2): $address = $etitle[0]; endif; foreach($data as $k=>$list): $dq = db("address")->where("etitle",$address)->find();if($dq): $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["title"]=$dq["title"].$list["title"];$list["url"] = "/show/".$dq["etitle"]."_".$nav["url_static"]."/".$list["id"].".html";else: $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["url"] = "/".$nav["url_static"]."/".$list["id"].".html";endif; ?>
                <li> <a href="<?php echo $list['url']; ?>" title="<?php echo $list['title']; ?>">
                  <div class="text"><?php echo $list['title']; ?>
                    <div style="float:right"><?php echo date('Y-m-d',$list['create_Time']); ?></div>
                  </div>
                  </a>
                </li>
                <?php endforeach; $pages = $page; ?>
              </ul>
              <div class="user_base">
                <div class="rowFluid">
                  <div class="kzf-mod-new-btn-more">
                    <?php echo $pages; ?>
                  </div>
                </div>
                <script type="text/javascript" src="/template/pc/index/js/mvcpager.js"></script>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
  <div class="footer wow fadeInUp">
    <div class="rowFluid">
        <div class="span12">
            <div class="container">
                <div class="footer_content">
                    <div class="span4 col-xm-12">
                        <div class="footer_list">
                            <div class="span6">
                                <div class="bottom_logo">
                                    <div class="quick_navigation_title" >微信咨询</div>
                                    <img src="/uploads/20191010/346e58fb4bde47d97ee40b4ae1ba178b.png" alt="">
                                    <div style="text-align: center;width:100px;color:#fff;padding:10px 0">网站制作</div>
                                    <img src="/uploads/20191010/138d362daac263d66218901b7478c6f7.jpg" alt="">
                                    <div style="text-align: center;width:100px;color:#fff;padding:10px 0">设计咨询</div>
                                </div>
                            </div>

                            <div class="span6 col-xm-12">
                                <div class="quick_navigation">
                                    <div class="quick_navigation_title">快速导航</div>
                                    <ul>
                                        <li> <a href="/" title="首页">首页</a> </li>
                                        <?php $data = db("nav")->where("pid",0)->where("show",1)->limit(10)->order("sort","asc")->select();$address = input("title");$etitle = explode("_",$address); foreach($data as $k=>$nav): if(count($etitle)==2): $address = $etitle[0]; endif; $dq = db("address")->where("etitle",$address)->find(); if(($dq)): $nav["name"]=$dq["title"].$nav["name"]; $nav["url"]="/navs/".$dq["etitle"]."_".$nav["url_static"].".html"; else: $nav["url"]="/".$nav["url_static"].".html"; endif; ?>
                                            <li> <a href="<?php echo $nav['url']; ?>" title="<?php echo $nav['name']; ?>"><?php echo $nav['name']; ?></a> </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="span4 col-xm-6 col-xs-12">
                        <div class="footer_list">
                            <div class="footer_link">
                                <div class="footer_link_title">友情链接</div>
                                <ul id="frientLinks">
                                    <?php $data = db("links")->where("type",1)->limit(10)->order("sort","desc")->select(); foreach($data as $k=>$links): ?>
                                        <li><a href='<?php echo $links['url']; ?>' target='_blank'><?php echo $links['title']; ?></a> </li>
                                    <?php endforeach; ?>
                                    <div style="clear: both"></div>
                                </ul>
                                <div class="footer_link_title" style="margin-top: 20px">地区分站</div>
                                <ul>
                                    <?php if(($title)): $pid = db("address")->where("etitle",$title)->find();$data = db("address")->where("pid",$pid["id"])->select();if((!$data)): $data = db("address")->where("pid",$pid["pid"])->select();endif; else: $data = db("address")->where("static",1)->where("pid",0)->select();endif; foreach($data as $k=>$address): $address["url"]="/address/".$address["etitle"].".html"; ?>
                                        <li><a href='<?php echo $address['url']; ?>' target='_blank'><?php echo $address['title']; ?></a> </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="span4 col-xm-6 col-xs-12">
                        <div class="footer_list">
                            <div class="footer_cotact">
                                <div class="footer_cotact_title">联系方式</div>
                                <ul>
                                    <li><span class="footer_cotact_type">地址：</span><span class="footer_cotact_content">重庆市渝北区龙溪街道金龙路</span></li>
                                    <li><span class="footer_cotact_type">电话：</span><span class="footer_cotact_content"><a href="tel:17620917002" class="call">17620917002</a></span></li>
                                    <li><span class="footer_cotact_type">网址：</span><span class="footer_cotact_content"><a href="#" title="官网">www.dearests.cn</a></span></li>
                                    <li><span class="footer_cotact_type">邮箱：</span><span class="footer_cotact_content">425158482@qq.com</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright"> <yunu:config name="site_copyright" /></div>
        </div>
    </div>
</div>
</div>
</div>
</div>
</div>
</div>

</body>
</html>
