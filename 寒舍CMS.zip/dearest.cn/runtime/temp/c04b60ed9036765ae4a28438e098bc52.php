<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:64:"D:\phpstudy_pro\WWW\dearest.cn\/template/pc/index\list_jjfa.html";i:1570684303;s:67:"D:\phpstudy_pro\WWW\dearest.cn\template\pc\index\public_header.html";i:1570680120;s:68:"D:\phpstudy_pro\WWW\dearest.cn\template\pc\index\public_footer1.html";i:1570680551;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="format-detection" content="telephone=yes">
    <title><?php $navcon = db("nav")->where("id",$navid)->find();$address = input("title");$etitle = explode("_",$address); if(count($etitle)==2): $address = $etitle[0]; endif; $dq = db("address")->where("etitle",$address)->find(); if($dq): $navcon["name"]=$dq["title"].$navcon["name"]; $navcon["url"]="/navs/".$dq["etitle"]."_".$navcon["url_static"].".html"; else: $navcon["url"]="/".$navcon["url_static"].".html"; endif; ?><?php echo $navcon['name']; ?> - <?php $fileadd = CONF_PATH.DS."extra".DS."site.php"; \think\Config::load($fileadd, "", "site"); $titlew = input("title"); $etitle = explode("_",$titlew); if(($titlew)): if(count($etitle)==2): $titles = $etitle[0]; $configarr = \think\Config::get("f_seo_title","site"); $address = db("address")->where("etitle",$titles)->find(); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $titles = $title; $address = db("address")->where("etitle",$titles)->find(); if(($address)): $configarr = \think\Config::get("f_seo_title","site"); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $configarr = \think\Config::get("seo_title","site"); ?><?php echo $configarr; endif; endif; else: $configarr = \think\Config::get("seo_title","site"); ?><?php echo $configarr; endif; ?></title>
    <meta name="keywords" content="<?php $fileadd = CONF_PATH.DS."extra".DS."site.php"; \think\Config::load($fileadd, "", "site"); $titlew = input("title"); $etitle = explode("_",$titlew); if(($titlew)): if(count($etitle)==2): $titles = $etitle[0]; $configarr = \think\Config::get("f_seo_keywords","site"); $address = db("address")->where("etitle",$titles)->find(); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $titles = $title; $address = db("address")->where("etitle",$titles)->find(); if(($address)): $configarr = \think\Config::get("f_seo_keywords","site"); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $configarr = \think\Config::get("seo_keywords","site"); ?><?php echo $configarr; endif; endif; else: $configarr = \think\Config::get("seo_keywords","site"); ?><?php echo $configarr; endif; ?>">
    <meta name="description" content="<?php $fileadd = CONF_PATH.DS."extra".DS."site.php"; \think\Config::load($fileadd, "", "site"); $titlew = input("title"); $etitle = explode("_",$titlew); if(($titlew)): if(count($etitle)==2): $titles = $etitle[0]; $configarr = \think\Config::get("f_seo_description","site"); $address = db("address")->where("etitle",$titles)->find(); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $titles = $title; $address = db("address")->where("etitle",$titles)->find(); if(($address)): $configarr = \think\Config::get("f_seo_description","site"); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $configarr = \think\Config::get("seo_description","site"); ?><?php echo $configarr; endif; endif; else: $configarr = \think\Config::get("seo_description","site"); ?><?php echo $configarr; endif; ?>">
    <meta name="author" content="order by dede58.com" />
    <meta name="renderer" content="webkit">
    <!--ico-->
    <link rel="stylesheet" type="text/css" href="/template/pc/index/css/base.css" />
    <link rel="stylesheet" type="text/css" href="/template/pc/index/css/animate.min.css" />
    <link rel="stylesheet" type="text/css" href="/template/pc/index/css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="/template/pc/index/css/style.css" />
    <link rel="stylesheet" type="text/css" href="/template/pc/index/css/responsive.css" />
    <script src="/template/pc/index/js/jquery-1.11.0.min.js"></script>
    <script src="/template/pc/index/js/wow.min_1.js"></script>
    <script src="/template/pc/index/js/owl.carousel.min.js"></script>
    <script src="/template/pc/index/js/page.js"></script>
</head>
<body>

<div class="header">
    <div class="rowFluid">
        <div class="span2 col-md-12">
            <div class="logo">
                <a href="/" title="返回首页">
                    <img src="/uploads/20191010/b2aad0e34b511de03d30f714cc11534f.png" alt="响应式网络建设设计公司网站模板(自适应移动设备)" />
                </a>
            </div>
        </div>
        <div class="span8">
            <div class="mobileMenuBtn"><span class="span1"></span><span class="span2"></span><span class="span3"></span></div>
            <div class="mobileMenuBtn_shad"></div>
            <div class="header_menu">
                <ul id="menu">
                    <?php $navid = isset($navid) ? $navid : 0;  $topnav = isset($topnav) ? $topnav : 0;  ?>
                    <li><a href="/"  <?php if(($navid==0)): ?>class="active"<?php endif; ?> title="首页">首页</a></li>
                    <?php $data = db("nav")->where("pid",0)->where("show",1)->limit(10)->order("sort","asc")->select();$address = input("title");$etitle = explode("_",$address); foreach($data as $k=>$nav): if(count($etitle)==2): $address = $etitle[0]; endif; $dq = db("address")->where("etitle",$address)->find(); if(($dq)): $nav["name"]=$dq["title"].$nav["name"]; $nav["url"]="/navs/".$dq["etitle"]."_".$nav["url_static"].".html"; else: $nav["url"]="/".$nav["url_static"].".html"; endif; ?>
                        <li><a href="<?php echo $nav['url']; ?>" <?php if($navid==$nav["id"]||$topnav==$nav['id']): ?>class="active"<?php endif; ?> title="<?php echo $nav['name']; ?>"><?php echo $nav['name']; ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <div class="span2"> </div>
    </div>
</div>
<div class="aside">
    <ul>
        <li class="consulting"> <a href="#this"  title="合作"><img src="/template/pc/index/images/057.png" alt="合作" />合作</a> </li>
        <li class="consulting">
            <a href="#this" title="建站在线客服">
                <span></span>
                <span></span>
                <span></span>
                <img src="/template/pc/index/images/059.png" class="img1" alt="建站在线客服" />
                <img src="/template/pc/index/images/061.png" class="img2" alt="建站在线客服" />咨询
            </a>
        </li>
        <li >
            <yunu:type typeid='92'>
                <a href="">
                    <img src="/template/pc/index/images/060.png" alt="建站帮助中心" />帮助
                </a>
            </yunu:type>
        </li>
    </ul>
</div>
<!--yinchang-->
<div class="consulting_box">
    <div class="title">
        <div class="title_t1">RELATEED CONSULTING</div>
        <div class="title_t2">相关咨询 </div>
    </div>
    <div class="consulting_type">
        <div class="consulting_type_title">选择下列产品马上在线沟通</div>
        <ul>
            <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" title="响应式建站咨询"> <img src="/template/pc/index/images/062.png" class="img1" alt="网站建设" /><img src="/template/pc/index/images/063.png" class="img2" alt="响应式网站咨询" />建站咨询 </a> </li>
            <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" title="建站平台加盟咨询"> <img src="/template/pc/index/images/062.png" class="img1" alt="建站平台" /><img src="/template/pc/index/images/063.png" class="img2" alt="建站平台代理咨询" />加盟咨询 </a> </li>
            <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=&site=qq&menu=yes" title="设计咨询"> <img src="/template/pc/index/images/062.png" class="img1" alt="设计咨询" /><img src="/template/pc/index/images/063.png" class="img2" alt="设计咨询" />设计咨询 </a> </li>
        </ul>
        <div class="time">服务时间：9:30-18:00</div>
    </div>
    <div class="problem">
        <div class="problem_title">你可能遇到了下面的问题</div>
        <ul>
            <?php $nav = db("nav")->where("id",10)->find();$model = db("models")->where("id",$nav["model"])->find();$table = "new_".$model["bname"];$res = db("nav")->where("id",10)->select();$navids = numbernav($res);$data = db("content")->where("pid","in",$navids)->where("reco","in","0,1")->limit(5)->order("create_Time desc")->select();$address = input("title");$etitle = explode("_",$address);if(count($etitle)==2): $address = $etitle[0]; endif; foreach($data as $k=>$list): $dq = db("address")->where("etitle",$address)->find();if($dq): $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["title"]=$dq["title"].$list["title"];$list["url"] = "/show/".$dq["etitle"]."_".$nav["url_static"]."/".$list["id"].".html";else: $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["url"] = "/".$nav["url_static"]."/".$list["id"].".html";endif; ?>
                <li><span></span><a href="<?php echo $list['url']; ?>" title="<?php echo $list['title']; ?>"><?php echo $list['title']; ?></a></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <div class="close"> <img src="/template/pc/index/images/close.png" alt="关闭右侧工具栏" /> </div>
</div>
<div class="page">
    <div class="rowFluid">
        <div class="span12">
            <div class="main">
                <link href="/template/pc/index/css/style_10.css" rel="stylesheet" />
                <body>
                <div class="page">
                    <div class="rowFluid">
                        <div class="span12">
                            <div class="main">
                                <div class="z_banner support_z_banner">
                                    <div class="rowFluid">
                                        <div class="span12">
                                            <div class="container">
                                                <h3 class="z_banner_title">
                                                    <?php $navcon = db("nav")->where("id",$navid)->find();$address = input("title");$etitle = explode("_",$address); if(count($etitle)==2): $address = $etitle[0]; endif; $dq = db("address")->where("etitle",$address)->find(); if($dq): $navcon["name"]=$dq["title"].$navcon["name"]; $navcon["url"]="/navs/".$dq["etitle"]."_".$navcon["url_static"].".html"; else: $navcon["url"]="/".$navcon["url_static"].".html"; endif; ?><?php echo $navcon['name']; ?>
                                                </h3>
                                                <div class="z_banner_text">
                                                    <?php $navcon = db("nav")->where("id",$navid)->find();$address = input("title");$etitle = explode("_",$address); if(count($etitle)==2): $address = $etitle[0]; endif; $dq = db("address")->where("etitle",$address)->find(); if($dq): $navcon["name"]=$dq["title"].$navcon["name"]; $navcon["url"]="/navs/".$dq["etitle"]."_".$navcon["url_static"].".html"; else: $navcon["url"]="/".$navcon["url_static"].".html"; endif; ?><?php echo $navcon['cname']; ?>
                                                </div>
                                            </div>
                                            <ul class="platform_advantage_bg_z">
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="kzf-mod-product">
                                    <div class="rowFluid">
                                        <div class="container">
                                            <div class="kzf-mod-product-header wow fadeInUp">
                                                <h1 class="kzf-mod-product-title">产品与服务</h1>
                                                <p class="kzf-mod-product-brief">我们提供数字平台建设与数字产品设计运营的全产业链服务，从设计制作到开发运营，一站式帮您搞定。</p>
                                            </div>
                                            <div class="kzf-mod-product-content">
                                                <div class="span3 col-sm-6">
                                                    <div class="kzf-mod-product-list wow fadeInLeft"> <img src="/template/pc/index/images/mod-product01.png" alt="高端响应式网站定制" />
                                                        <div class="kzf-mod-product-list-title">高端响应式网站定制</div>
                                                        <p>完美响应各种设备</p>
                                                        <p>高端网站视觉设计</p>
                                                        <p>精湛交互动画体验</p>
                                                        <p>运行稳定安全可靠</p>
                                                        <p>实力定制功能研发</p>
                                                    </div>
                                                </div>
                                                <div class="span3 col-sm-6">
                                                    <div class="kzf-mod-product-list wow fadeInUp"> <img src="/template/pc/index/images/mod-product02.png" alt="响应式电商网站方案" />
                                                        <div class="kzf-mod-product-list-title">响应式电商网站方案</div>
                                                        <p>独立自主商城品牌</p>
                                                        <p>跨屏完美购物体验</p>
                                                        <p>微信全面无缝对接</p>
                                                        <p>商城互动营销方案</p>
                                                        <p>手机商城APP整合</p>
                                                    </div>
                                                </div>
                                                <div class="span3 col-sm-6">
                                                    <div class="kzf-mod-product-list wow fadeInUp"> <img src="/template/pc/index/images/mod-product03.png" alt="微信深度定制开发" />
                                                        <div class="kzf-mod-product-list-title">微信深度定制开发</div>
                                                        <p>微信行业解决方案</p>
                                                        <p>H5互动解决方案</p>
                                                        <p>微信营销解决方案</p>
                                                        <p>个性定制解决方案</p>
                                                    </div>
                                                </div>
                                                <div class="span3 col-sm-6">
                                                    <div class="kzf-mod-product-list wow fadeInRight"> <img src="/template/pc/index/images/mod-product04.png" alt="网站运营服务" />
                                                        <div class="kzf-mod-product-list-title">网站运营服务</div>
                                                        <p>设计运维托管服务</p>
                                                        <p>SEO推广优化服务</p>
                                                        <p>SMO互动营销策划</p>
                                                        <p>微信公众平台运营</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="kzf-mod-custom">
                                    <div class="rowFluid">
                                        <div class="container">
                                            <div class="kzf-mod-custom-header wow fadeInUp">
                                                <h1 class="kzf-mod-custom-title">高端定制流程</h1>
                                                <p class="kzf-mod-custom-brief">用前沿的思维制作交互式用户体验的高端网站，正是我们的优势所在。</p>
                                            </div>
                                            <div class="kzf-mod-custom-content">
                                                <div class="col-xs-12">
                                                    <div class="kzf-mod-custom-list wow fadeInUp"> <img src="/template/pc/index/images/mod-custom01.png" alt="厦门网站建设-需求沟通" />
                                                        <div class="kzf-mod-custom-list-title">需求沟通</div>
                                                        <p>倾听客户需求，了解用户使用环境和操作流程</p>
                                                    </div>
                                                    <div class="kzf-mod-custom-list wow fadeInUp" style="animation-delay: 0.1s;"> <img src="/template/pc/index/images/mod-custom02.png" alt="厦门网站建设-项目策划" />
                                                        <div class="kzf-mod-custom-list-title">项目策划</div>
                                                        <p>头脑风景交互情景模拟原型设计</p>
                                                    </div>
                                                    <div class="kzf-mod-custom-list wow fadeInUp" style="animation-delay: 0.2s;"> <img src="/template/pc/index/images/mod-custom03.png" alt="厦门网站建设-交互设计" />
                                                        <div class="kzf-mod-custom-list-title">交互设计</div>
                                                        <p>从用户的角度思考，模拟用户行为</p>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12">
                                                    <div class="kzf-mod-custom-list wow fadeInUp" style="animation-delay: 0.3s;"> <img src="/template/pc/index/images/mod-custom04.png" alt="响应式网站建设-视觉创意" />
                                                        <div class="kzf-mod-custom-list-title">视觉创意</div>
                                                        <p>色彩及平面元素设定，结构和布局规范确认</p>
                                                    </div>
                                                    <div class="kzf-mod-custom-list wow fadeInUp" style="animation-delay: 0.4s;"> <img src="/template/pc/index/images/mod-custom05.png" alt="响应式网站建设-前端制作" />
                                                        <div class="kzf-mod-custom-list-title">前端制作</div>
                                                        <p>HTML5、CSS3、JS实现页面的动态展示</p>
                                                    </div>
                                                    <div class="kzf-mod-custom-list wow fadeInUp" style="animation-delay: 0.5s;"> <img src="/template/pc/index/images/mod-custom06.png" alt="响应式网站建设-技术开发" />
                                                        <div class="kzf-mod-custom-list-title">技术开发</div>
                                                        <p>移动应用数据对接与开发</p>
                                                    </div>
                                                </div>
                                                <div class="kzf-mod-custom-list kzf-mod-custom-list-last wow fadeInUp " style="animation-delay: 0.6s;"> <img src="/template/pc/index/images/mod-custom07.png" alt="响应式网站建设-测试反馈" />
                                                    <div class="kzf-mod-custom-list-title">测试反馈</div>
                                                    <p>修改调整，规范完善</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="kzf-mod-case-container">
                                    <div class="rowFluid">
                                        <div class="container">
                                            <div class="span12">
                                                <div class="kzf-mod-case-out">
                                                    <div class="kzf-mod-so-title-box wow fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;">
                                                        <h3 class="kzf-so-title">经典案例</h3>
                                                        <div class="kzf-so-text">精选特殊网站案例，分享创意与智慧</div>
                                                    </div>
                                                    <div class="kzf-mod-case-box">
                                                        <?php $nav = db("nav")->where("id",3)->find();$model = db("models")->where("id",$nav["model"])->find();$table = "new_".$model["bname"];$res = db("nav")->where("id",3)->select();$navids = numbernav($res);$data = db("content")->where("pid","in",$navids)->where("reco","in","0,1")->limit(100)->order("create_Time")->select();$address = input("title");$etitle = explode("_",$address);if(count($etitle)==2): $address = $etitle[0]; endif; foreach($data as $k=>$list): $dq = db("address")->where("etitle",$address)->find();if($dq): $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["title"]=$dq["title"].$list["title"];$list["url"] = "/show/".$dq["etitle"]."_".$nav["url_static"]."/".$list["id"].".html";else: $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["url"] = "/".$nav["url_static"]."/".$list["id"].".html";endif; ?>
                                                            <div class="span6 col-sm-12">
                                                                <a href="<?php echo $list['url']; ?>" title="<?php echo $list['title']; ?>">
                                                                    <div class="kzf-mod-wrap wow fadeInUp">
                                                                        <div class="kzf-mod-pic">
                                                                            <img class="img" src="<?php echo $list['pic']; ?>" alt="<?php echo $list['title']; ?>" />
                                                                        </div>
                                                                        <div class="kzf-mod-title">
                                                                            <p><?php echo $list['title']; ?></p>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        <?php endforeach; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="kzf-mod-link-container">
    <div class="rowFluid">
        <div class="container">
            <div class="span12">
                <div class="kzf-mod-link-out">
                    <div class="kzf-mod-so-title-box wow fadeInDown" style="visibility: visible; animation-name: fadeInDown;">
                        <h3 class="kzf-so-title">联系我们</h3>
                        <div class="kzf-so-text">一切良好工作的开始，都需相互之间的沟通搭桥，欢迎咨询。</div>
                    </div>
                    <div class="rowFluid">
                        <div class="kzf-mod-link-inf-box">
                            <div class="span3 col-sm-6 col-xs-12"> <a href="tel:17620917002">
                                <div class="kzf-mod-wrap wow fadeInLeft">
                                    <div class="kzf-mod-pic"> <img src="/template/pc/index/images/so-iphone.png" alt="联系网站建设电话"/> </div>
                                    <div class="kzf-mod-txt">
                                        <p>17620917002</p>
                                    </div>
                                </div>
                            </a> </div>
                            <div class="span3 col-sm-6 col-xs-12"> <a href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" target="_blank">
                                <div class="kzf-mod-wrap wow fadeInRight">
                                    <div class="kzf-mod-pic"> <img src="/template/pc/index/images/so-qq.png" alt="联系QQ" /> </div>
                                    <div class="kzf-mod-txt">
                                        <p>425158482</p>
                                    </div>
                                </div>
                            </a> </div>
                            <div class="span3 col-sm-6 col-xs-12"> <a href="mailto:<yunu:block name='qq' />@qq.com">
                                <div class="kzf-mod-wrap wow fadeInLeft">
                                    <div class="kzf-mod-pic"> <img src="/template/pc/index/images/so-mail.png" alt="联系网站建设邮箱" /> </div>
                                    <div class="kzf-mod-txt">
                                        <p>425158482@qq.com</p>
                                    </div>
                                </div>
                            </a> </div>
                            <div class="span3 col-sm-6 col-xs-12"> <a href="#">
                                <div class="kzf-mod-wrap wow fadeInRight">
                                    <div class="kzf-mod-pic"> <img src="/template/pc/index/images/so-location.png" alt="联系网站建设地址" /> </div>
                                    <div class="kzf-mod-txt">
                                        <p>重庆市渝北区龙溪街道金龙路</p>
                                    </div>
                                </div>
                            </a> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

                            </div>
                        </div>
                    </div>
                </div>
                </body>
            </div>
        </div>
    </div>
</div>

</body>
</html>
