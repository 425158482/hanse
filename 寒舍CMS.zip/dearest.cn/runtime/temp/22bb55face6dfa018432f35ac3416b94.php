<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:72:"D:\phpstudy_pro\WWW\dearest.cn/application/admini\view\debris\index.html";i:1570334319;s:71:"D:\phpstudy_pro\WWW\dearest.cn\application\admini\view\public\head.html";i:1570520864;s:71:"D:\phpstudy_pro\WWW\dearest.cn\application\admini\view\public\menu.html";i:1570081613;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>寒舍CMS_管理后台</title>
<link rel="shortcut icon" href="/static/admin/images/favicon.ico">
<link rel="stylesheet" href="/static/admin/layui/css/layui.css">
<link rel="stylesheet" href="/static/admin/css/style.css">
<script src="/static/admin/layui/layui.js"></script>
<script src="/static/admin/js/jquery-1.10.2.min.js"></script>


</head>
<body>
<div class="top_menu">
    <div class="left">
        <a href="<?php echo url('index/index'); ?>">管理控制台</a>
    </div>
    <div class="left">
        <?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$me): $mod = ($i % 2 );++$i;?>
        <a href="<?php echo $me['url']; ?>.html" class="<?php if(($me['id']==$curl)): ?>t_curl<?php endif; ?> "><i class="layui-icon <?php echo $me['ico']; ?>"></i><?php echo $me['title']; ?></a>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
    <div class="right">
        <a href="/" target="_blank" title="首页"><i class="layui-icon layui-icon-release"></i></a>
        <a class="cache" title="清除缓存"><i class="layui-icon layui-icon-delete"></i></a>
        <a href="" title="更换主题"><i class="layui-icon layui-icon-theme"></i></a>
        <a class="logoaut" title="退出"><i class="layui-icon layui-icon-radio"></i></a>
    </div>
    <div style="clear: both"></div>
</div>
<script>
    layui.use(['jquery','form','element', 'layedit','upload'], function() {
        var form = layui.form
            , layer = layui.layer
            , jquery = layui.jquery;
        //询问框
        $(".logoaut").click(function () {
            layer.confirm('确定要退出当前账户吗？', {
                btn: ['确定','关闭'] //按钮
            }, function(){
                jquery.ajax({
                    type: "post",
                    url: "<?php echo url('login/logoaut'); ?>",
                    success: function (msg) {
                        if(msg==1){
                            layer.msg('退出成功', {icon: 1,time: 1000}, function() {
                                location.href="<?php echo url('login/login'); ?>";
                            });
                        }

                    }
                })
            });
        })
        //询问框
        $(".cache").click(function () {
            layer.confirm('确定要清除缓存？', {
                btn: ['确定','关闭'] //按钮
            }, function(){
                jquery.ajax({
                    type: "post",
                    url: "<?php echo url('index/caches'); ?>",
                    success: function (msg) {
                        console.log(msg)
                        if(msg==1){
                            layer.msg('清除成功', {icon: 1,time: 1000});
                        }
                    }
                })
            });
        })

    })
</script>
<!--左边栏目-->
<div class="left_menu">
    <div class="menu">
        <div class="touxiang">
            <a href="<?php echo url('index/editadmin'); ?>">
                <div style="background: #fff"><img src="<?php echo \think\Session::get('admini.pic'); ?>" alt=""></div>
                <div><?php echo \think\Session::get('admini.name'); ?></div>
                <div style="clear: both"></div>
            </a>

        </div>
        <?php if(is_array($menusub) || $menusub instanceof \think\Collection || $menusub instanceof \think\Paginator): $i = 0; $__LIST__ = $menusub;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$menusubs): $mod = ($i % 2 );++$i;?>
        <a href="<?php echo $menusubs['url']; ?>.html" class=" <?php if(($menusubs['id']==$action)): ?>t_curl<?php endif; ?> ">
            <i class="layui-icon <?php echo $menusubs['ico']; ?>"></i>
            <?php echo $menusubs['title']; ?>
        </a>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
</div>
<!--中间内容-->

<div class="admin_main">
    <div class="container">
        <blockquote class="layui-elem-quote">数据碎片</blockquote>
        <div class="btn_tj">
            <a href="<?php echo url('debris/add'); ?>" class="layui-btn layui-btn-sm"><i class="layui-icon"></i>添加数据</a>
        </div>
        <div class="layui-form">
            <table class="layui-table">
                <colgroup>
                    <col width="50">
                    <col width="200">
                    <col>
                    <col>
                    <col width="250">
                    <col width="130">

                </colgroup>
                <thead>
                <tr>
                    <th>ID</th>
                    <th>碎片名称</th>
                    <th>中文标志</th>
                    <th>类型</th>
                    <th>调用代码</th>
                    <th>操作</th>
                </tr>
                </thead>
                <tbody>
                <?php if(is_array($debris) || $debris instanceof \think\Collection || $debris instanceof \think\Paginator): $i = 0; $__LIST__ = $debris;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$debris): $mod = ($i % 2 );++$i;?>
                <tr>
                    <td><?php echo $debris['id']; ?></td>
                    <td><?php echo $debris['title']; ?></td>
                    <td><?php echo $debris['name']; ?></td>
                    <td>
                        <?php if(($debris['type']==1)): ?>
                        文字
                        <?php elseif(($debris['type']==2)): ?>
                        图片
                        <?php elseif(($debris['type']==3)): ?>
                        编辑器
                        <?php endif; ?>
                    </td>
                    <td>{hs:debris title="<?php echo $debris['title']; ?>" /}</td>
                    <td>
                        <a href="<?php echo url('debris/edit',['id'=>$debris['id']]); ?>" type="button" class="layui-btn layui-btn-primary layui-btn-sm"><i class="layui-icon"></i></a>
                        <button class="layui-btn layui-btn-primary layui-btn-sm delete" data-id="<?php echo $debris['id']; ?>"><i class="layui-icon"></i></button>
                    </td>
                </tr>
                <?php endforeach; endif; else: echo "" ;endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    layui.use(['jquery','form', 'layedit'], function() {
        var form = layui.form
            , layer = layui.layer
            , jquery = layui.jquery
            , layedit = layui.layedit;
        $(document).on('blur','.sort', function () {
            var id = $(this).attr('data-id');
            var obs = $(this);
            $.ajax({
                type: "POST",
                url: '<?php echo url("banner/editsort"); ?>',
                data:{'id':id,'sort':obs.val()},
                success: function(msg){
                    if(msg){
                        layer.msg('排序已更改', {icon: 1});
                    }else{
                        layer.msg('排序更改失败', {icon: 5});
                    }
                }
            });
        });
        $(document).on('click','.delete', function () {
            var id = $(this).attr('data-id');
            layer.confirm('确定要删除吗？', {
                btn: ['必须的','忍一手'] //按钮
            }, function(){
                $.ajax({
                    type: "POST",
                    url: '<?php echo url("debris/delete"); ?>',
                    data:{'id':id},
                    success: function(msg){
                        if(msg==1){
                            layer.msg('删除成功', {icon: 1,time:1000}, function() {
                                location.href="<?php echo url('debris/index'); ?>";
                            });
                            location.href;
                        }else if(msg==0){
                            layer.msg('系统繁忙', {icon: 5});
                        }else{
                            layer.msg('系统繁忙', {icon: 5});
                        }
                    }
                });
            });
        })
        $(".bannerpic").click(function () {
            var img = $(this).data("pic");
            layer.open({
                type: 1,
                title: false,
                closeBtn: 0,
                area: '516px',
                skin: '', //没有背景色
                shadeClose: true,
                content: "<img src='"+ img +"' style='width: 516px;'>"
            });
        })
    })
</script>




















</body>
</html>