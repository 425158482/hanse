<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:71:"D:\phpstudy_pro\WWW\dearest.cn/application/admini\view\index\index.html";i:1570327029;s:71:"D:\phpstudy_pro\WWW\dearest.cn\application\admini\view\public\head.html";i:1570520864;s:71:"D:\phpstudy_pro\WWW\dearest.cn\application\admini\view\public\menu.html";i:1570081613;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>寒舍CMS_管理后台</title>
<link rel="shortcut icon" href="/static/admin/images/favicon.ico">
<link rel="stylesheet" href="/static/admin/layui/css/layui.css">
<link rel="stylesheet" href="/static/admin/css/style.css">
<script src="/static/admin/layui/layui.js"></script>
<script src="/static/admin/js/jquery-1.10.2.min.js"></script>


    <script src="https://cdn.bootcss.com/echarts/4.3.0-rc.2/echarts.min.js"></script>
</head>
<body>
<!--头部栏目-->
<div class="top_menu">
    <div class="left">
        <a href="<?php echo url('index/index'); ?>">管理控制台</a>
    </div>
    <div class="left">
        <?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$me): $mod = ($i % 2 );++$i;?>
        <a href="<?php echo $me['url']; ?>.html" class="<?php if(($me['id']==$curl)): ?>t_curl<?php endif; ?> "><i class="layui-icon <?php echo $me['ico']; ?>"></i><?php echo $me['title']; ?></a>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
    <div class="right">
        <a href="/" target="_blank" title="首页"><i class="layui-icon layui-icon-release"></i></a>
        <a class="cache" title="清除缓存"><i class="layui-icon layui-icon-delete"></i></a>
        <a href="" title="更换主题"><i class="layui-icon layui-icon-theme"></i></a>
        <a class="logoaut" title="退出"><i class="layui-icon layui-icon-radio"></i></a>
    </div>
    <div style="clear: both"></div>
</div>
<script>
    layui.use(['jquery','form','element', 'layedit','upload'], function() {
        var form = layui.form
            , layer = layui.layer
            , jquery = layui.jquery;
        //询问框
        $(".logoaut").click(function () {
            layer.confirm('确定要退出当前账户吗？', {
                btn: ['确定','关闭'] //按钮
            }, function(){
                jquery.ajax({
                    type: "post",
                    url: "<?php echo url('login/logoaut'); ?>",
                    success: function (msg) {
                        if(msg==1){
                            layer.msg('退出成功', {icon: 1,time: 1000}, function() {
                                location.href="<?php echo url('login/login'); ?>";
                            });
                        }

                    }
                })
            });
        })
        //询问框
        $(".cache").click(function () {
            layer.confirm('确定要清除缓存？', {
                btn: ['确定','关闭'] //按钮
            }, function(){
                jquery.ajax({
                    type: "post",
                    url: "<?php echo url('index/caches'); ?>",
                    success: function (msg) {
                        console.log(msg)
                        if(msg==1){
                            layer.msg('清除成功', {icon: 1,time: 1000});
                        }
                    }
                })
            });
        })

    })
</script>
<!--左边栏目-->
<div class="left_menu">
    <div class="menu">
        <div class="touxiang">
            <a href="<?php echo url('index/editadmin'); ?>">
                <div style="background: #fff"><img src="<?php echo \think\Session::get('admini.pic'); ?>" alt=""></div>
                <div><?php echo \think\Session::get('admini.name'); ?></div>
                <div style="clear: both"></div>
            </a>

        </div>
        <?php if(is_array($menusub) || $menusub instanceof \think\Collection || $menusub instanceof \think\Paginator): $i = 0; $__LIST__ = $menusub;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$menusubs): $mod = ($i % 2 );++$i;?>
        <a href="<?php echo $menusubs['url']; ?>.html" class=" <?php if(($menusubs['id']==$action)): ?>t_curl<?php endif; ?> ">
            <i class="layui-icon <?php echo $menusubs['ico']; ?>"></i>
            <?php echo $menusubs['title']; ?>
        </a>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
</div>
<!--中间内容-->
<div class="admin_main">
    <div class="container">
        <blockquote class="layui-elem-quote">
            欢迎 : <a href="<?php echo url('index/editadmin'); ?>"><?php echo \think\Session::get('admini.name'); ?></a> IP : <?php echo \think\Session::get('admini.ip'); ?> 时间 : <?php echo date("Y-m-d H:i:s",\think\Session::get('admini.create_time')); ?>
        </blockquote>
        <div class="layui-row">
            <?php if(is_array($inav) || $inav instanceof \think\Collection || $inav instanceof \think\Paginator): $i = 0; $__LIST__ = $inav;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$inav): $mod = ($i % 2 );++$i;?>
            <div class="layui-col-xs3" style="text-align: center">
                <div class="layui-col-xs10 ad_in_na">
                    <?php if($inav['model']==4): ?>
                    <a href="<?php echo url('nav/edit',['id'=>$inav['id']]); ?>"><?php echo $inav['name']; ?></a>
                    <?php else: ?>
                    <a href="<?php echo url('content/content',['id'=>$inav['id']]); ?>"><?php echo $inav['name']; ?></a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
        <blockquote class="layui-elem-quote" style="margin-top: 20px">
            访问统计
        </blockquote>
        <div id="mains" style="height:400px;"></div>
    </div>


</div>
















<script type="text/javascript">
    // 基于准备好的dom，初始化echarts实例
    var myChart = echarts.init(document.getElementById('mains'));

    // 指定图表的配置项和数据
    var option = {
        title: {
            text: '统计走势图'
        },
        tooltip: {},
        xAxis: {
            data: [<?php echo $time; ?>]
        },
        yAxis: {},
        series: [{
            name: '访问人数',
            type: 'bar',
            data: [<?php echo $num; ?>]
        }]
    };

    // 使用刚指定的配置项和数据显示图表。
    myChart.setOption(option);
</script>




</body>
</html>