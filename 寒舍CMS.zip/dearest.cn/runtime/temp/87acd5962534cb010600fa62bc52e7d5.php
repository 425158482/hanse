<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:60:"D:\phpstudy_pro\WWW\dearest.cn\/template/pc/index\index.html";i:1570684519;s:67:"D:\phpstudy_pro\WWW\dearest.cn\template\pc\index\public_header.html";i:1570680120;s:67:"D:\phpstudy_pro\WWW\dearest.cn\template\pc\index\public_footer.html";i:1570679555;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="format-detection" content="telephone=yes">
    <title><?php $fileadd = CONF_PATH.DS."extra".DS."site.php"; \think\Config::load($fileadd, "", "site"); $titlew = input("title"); $etitle = explode("_",$titlew); if(($titlew)): if(count($etitle)==2): $titles = $etitle[0]; $configarr = \think\Config::get("f_seo_title","site"); $address = db("address")->where("etitle",$titles)->find(); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $titles = $title; $address = db("address")->where("etitle",$titles)->find(); if(($address)): $configarr = \think\Config::get("f_seo_title","site"); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $configarr = \think\Config::get("seo_title","site"); ?><?php echo $configarr; endif; endif; else: $configarr = \think\Config::get("seo_title","site"); ?><?php echo $configarr; endif; ?></title>
    <meta name="keywords" content="<?php $fileadd = CONF_PATH.DS."extra".DS."site.php"; \think\Config::load($fileadd, "", "site"); $titlew = input("title"); $etitle = explode("_",$titlew); if(($titlew)): if(count($etitle)==2): $titles = $etitle[0]; $configarr = \think\Config::get("f_seo_keywords","site"); $address = db("address")->where("etitle",$titles)->find(); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $titles = $title; $address = db("address")->where("etitle",$titles)->find(); if(($address)): $configarr = \think\Config::get("f_seo_keywords","site"); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $configarr = \think\Config::get("seo_keywords","site"); ?><?php echo $configarr; endif; endif; else: $configarr = \think\Config::get("seo_keywords","site"); ?><?php echo $configarr; endif; ?>">
    <meta name="description" content="<?php $fileadd = CONF_PATH.DS."extra".DS."site.php"; \think\Config::load($fileadd, "", "site"); $titlew = input("title"); $etitle = explode("_",$titlew); if(($titlew)): if(count($etitle)==2): $titles = $etitle[0]; $configarr = \think\Config::get("f_seo_description","site"); $address = db("address")->where("etitle",$titles)->find(); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $titles = $title; $address = db("address")->where("etitle",$titles)->find(); if(($address)): $configarr = \think\Config::get("f_seo_description","site"); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $configarr = \think\Config::get("seo_description","site"); ?><?php echo $configarr; endif; endif; else: $configarr = \think\Config::get("seo_description","site"); ?><?php echo $configarr; endif; ?>">
    <link rel="stylesheet" type="text/css" href="/template/pc/index/css/base.css" />
    <link rel="stylesheet" type="text/css" href="/template/pc/index/css/animate.min.css" />
    <link rel="stylesheet" type="text/css" href="/template/pc/index/css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="/template/pc/index/css/style.css" />
    <link rel="stylesheet" type="text/css" href="/template/pc/index/css/responsive.css" />
    <script src="/template/pc/index/js/jquery-1.11.0.min.js"></script>
    <script src="/template/pc/index/js/wow.min_1.js"></script>
    <script src="/template/pc/index/js/owl.carousel.min.js"></script>
    <script src="/template/pc/index/js/page.js"></script>
    <script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "https://hm.baidu.com/hm.js?48ea3231e25f2f4a106eb435ff890c77";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>
</head>
<body>

<div class="header">
    <div class="rowFluid">
        <div class="span2 col-md-12">
            <div class="logo">
                <a href="/" title="返回首页">
                    <img src="/uploads/20191010/b2aad0e34b511de03d30f714cc11534f.png" alt="响应式网络建设设计公司网站模板(自适应移动设备)" />
                </a>
            </div>
        </div>
        <div class="span8">
            <div class="mobileMenuBtn"><span class="span1"></span><span class="span2"></span><span class="span3"></span></div>
            <div class="mobileMenuBtn_shad"></div>
            <div class="header_menu">
                <ul id="menu">
                    <?php $navid = isset($navid) ? $navid : 0;  $topnav = isset($topnav) ? $topnav : 0;  ?>
                    <li><a href="/"  <?php if(($navid==0)): ?>class="active"<?php endif; ?> title="首页">首页</a></li>
                    <?php $data = db("nav")->where("pid",0)->where("show",1)->limit(10)->order("sort","asc")->select();$address = input("title");$etitle = explode("_",$address); foreach($data as $k=>$nav): if(count($etitle)==2): $address = $etitle[0]; endif; $dq = db("address")->where("etitle",$address)->find(); if(($dq)): $nav["name"]=$dq["title"].$nav["name"]; $nav["url"]="/navs/".$dq["etitle"]."_".$nav["url_static"].".html"; else: $nav["url"]="/".$nav["url_static"].".html"; endif; ?>
                        <li><a href="<?php echo $nav['url']; ?>" <?php if($navid==$nav["id"]||$topnav==$nav['id']): ?>class="active"<?php endif; ?> title="<?php echo $nav['name']; ?>"><?php echo $nav['name']; ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <div class="span2"> </div>
    </div>
</div>
<div class="aside">
    <ul>
        <li class="consulting"> <a href="#this"  title="合作"><img src="/template/pc/index/images/057.png" alt="合作" />合作</a> </li>
        <li class="consulting">
            <a href="#this" title="建站在线客服">
                <span></span>
                <span></span>
                <span></span>
                <img src="/template/pc/index/images/059.png" class="img1" alt="建站在线客服" />
                <img src="/template/pc/index/images/061.png" class="img2" alt="建站在线客服" />咨询
            </a>
        </li>
        <li >
            <yunu:type typeid='92'>
                <a href="">
                    <img src="/template/pc/index/images/060.png" alt="建站帮助中心" />帮助
                </a>
            </yunu:type>
        </li>
    </ul>
</div>
<!--yinchang-->
<div class="consulting_box">
    <div class="title">
        <div class="title_t1">RELATEED CONSULTING</div>
        <div class="title_t2">相关咨询 </div>
    </div>
    <div class="consulting_type">
        <div class="consulting_type_title">选择下列产品马上在线沟通</div>
        <ul>
            <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" title="响应式建站咨询"> <img src="/template/pc/index/images/062.png" class="img1" alt="网站建设" /><img src="/template/pc/index/images/063.png" class="img2" alt="响应式网站咨询" />建站咨询 </a> </li>
            <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" title="建站平台加盟咨询"> <img src="/template/pc/index/images/062.png" class="img1" alt="建站平台" /><img src="/template/pc/index/images/063.png" class="img2" alt="建站平台代理咨询" />加盟咨询 </a> </li>
            <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=&site=qq&menu=yes" title="设计咨询"> <img src="/template/pc/index/images/062.png" class="img1" alt="设计咨询" /><img src="/template/pc/index/images/063.png" class="img2" alt="设计咨询" />设计咨询 </a> </li>
        </ul>
        <div class="time">服务时间：9:30-18:00</div>
    </div>
    <div class="problem">
        <div class="problem_title">你可能遇到了下面的问题</div>
        <ul>
            <?php $nav = db("nav")->where("id",10)->find();$model = db("models")->where("id",$nav["model"])->find();$table = "new_".$model["bname"];$res = db("nav")->where("id",10)->select();$navids = numbernav($res);$data = db("content")->where("pid","in",$navids)->where("reco","in","0,1")->limit(5)->order("create_Time desc")->select();$address = input("title");$etitle = explode("_",$address);if(count($etitle)==2): $address = $etitle[0]; endif; foreach($data as $k=>$list): $dq = db("address")->where("etitle",$address)->find();if($dq): $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["title"]=$dq["title"].$list["title"];$list["url"] = "/show/".$dq["etitle"]."_".$nav["url_static"]."/".$list["id"].".html";else: $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["url"] = "/".$nav["url_static"]."/".$list["id"].".html";endif; ?>
                <li><span></span><a href="<?php echo $list['url']; ?>" title="<?php echo $list['title']; ?>"><?php echo $list['title']; ?></a></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <div class="close"> <img src="/template/pc/index/images/close.png" alt="关闭右侧工具栏" /> </div>
</div>
<div class="page">
    <div class="rowFluid">
        <div class="span12">
            <div class="main">

                <div class="banner">
                    <div class="rowFluid">
                        <div class="span12">
                            <div class="owl-demo">
                                <?php $data = db("banner")->where("type",1)->limit(10)->select(); foreach($data as $k=>$banner): ?>
                                    <div class="item">
                                        <h3 class="banner_title"><?php echo $banner['name']; ?></h3>
                                        <div class="banner_text"><?php echo $banner['desc']; ?></div>
                                        <div class="banner_button"> <a href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" target="_blank" title="详细咨询">马上咨询</a> </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <div id="container" class="mpage">
                        <div id="anitOut" class="anitOut"></div>
                    </div>
                </div>
                <div class="index_product">
                    <div class="rowFluid">
                        <div class="span12">
                            <div class="container">
                                <div class="all_title1 wow fadeInDown">
                                    <h3 class="title">我们的产品</h3>
                                    <div class="text">OUR PRODUCT</div>
                                </div>
                                <div class="rowFluid">
                                    <div class="index_product_content">
                                        <div class="span4 col-md-6 col-xs-12 wow fadeInDown"> <a  class="index_product_list" title="响应式企业网站建设">
                                            <div class="list_backimg list_backimg1">
                                                <div class="list_img"> <img src="/template/pc/index/images/045.png" alt="响应式企业网站建设" /> </div>
                                                <div class="list_txt">
                                                    <div class="list_title">企业官网</div>
                                                    <div class="list_text">CORPORATE WEBSITES</div>
                                                </div>
                                            </div>
                                        </a> </div>
                                        <div class="span4 col-md-6 col-xs-12 wow flipInX"> <a  class="index_product_list" title="响应式商城网站建设">
                                            <div class="list_backimg list_backimg2">
                                                <div class="list_img"> <img src="/template/pc/index/images/046.png" alt="响应式商城网站建设" /> </div>
                                                <div class="list_txt">
                                                    <div class="list_title">购物商城</div>
                                                    <div class="list_text">SHOPPING MALL</div>
                                                </div>
                                            </div>
                                        </a> </div>
                                        <div class="span4 col-md-6 col-xs-12 wow fadeInRight"> <a  class="index_product_list" title="空间域名">
                                            <div class="list_backimg list_backimg3">
                                                <div class="list_img"> <img src="/template/pc/index/images/047.png" alt="空间域名" /> </div>
                                                <div class="list_txt">
                                                    <div class="list_title">空间域名</div>
                                                    <div class="list_text">SPACE SERVICE</div>
                                                </div>
                                            </div>
                                        </a> </div>
                                        <div class="span4 col-md-6 col-xs-12 wow fadeInDown"> <a  class="index_product_list" title="生态级行业门户">
                                            <div class="list_backimg list_backimg4">
                                                <div class="list_img"> <img src="/template/pc/index/images/048.png" alt="生态级行业门户" /> </div>
                                                <div class="list_txt">
                                                    <div class="list_title">行业门户</div>
                                                    <div class="list_text">INDUSTRY PORTAL</div>
                                                </div>
                                            </div>
                                        </a> </div>
                                        <div class="span4 col-md-6 col-xs-12 wow flipInX"> <a  class="index_product_list" title="H5三合一网站">
                                            <div class="list_backimg list_backimg5">
                                                <div class="list_img"> <img src="/template/pc/index/images/049.png" alt="H5三合一网站" /> </div>
                                                <div class="list_txt">
                                                    <div class="list_title">三合一网站</div>
                                                    <div class="list_text">TRIAD WEBSITE</div>
                                                </div>
                                            </div>
                                        </a> </div>
                                        <div class="span4 col-md-6 col-xs-12 wow fadeInRight"> <a  class="index_product_list" title="生态级响应式全网营销平台">
                                            <div class="list_backimg list_backimg6">
                                                <div class="list_img"> <img src="/template/pc/index/images/050.png" alt="生态级响应式全网营销平台" /> </div>
                                                <div class="list_txt">
                                                    <div class="list_title">全网营销</div>
                                                    <div class="list_text">NETWORK MARKETING</div>
                                                </div>
                                            </div>
                                        </a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="platform_advantage">
                    <div class="rowFluid">
                        <div class="span12">
                            <div class="container">
                                <div class="all_title2 wow fadeInUp">
                                    <h3 class="title">壹恩建站优势</h3>
                                    <div class="text">PLATFORM ADVANTAGE</div>
                                </div>
                                <div class="rowFluid">
                                    <div class="platform_advantage_content">
                                        <div class="span4 col-xm-6 col-xs-12 wow bounceInLeft">
                                            <div class="platform_advantage_list">
                                                <div class="platform_advantage_img"> <img src="/template/pc/index/images/008.png" alt="响应式建站平台" /> </div>
                                                <div class="platform_advantage_brief">
                                                    <div class="brief_title">成本价制作网站</div>
                                                    <div class="brief_text">只收空间域名维护取成本价</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="span4 col-xm-6 col-xs-12 wow bounceIn">
                                            <div class="platform_advantage_list">
                                                <div class="platform_advantage_img"> <img src="/template/pc/index/images/009.png" alt="响应式网站建设" /> </div>
                                                <div class="platform_advantage_brief">
                                                    <div class="brief_title">快速建站</div>
                                                    <div class="brief_text"> 打破传统网站制作工时<br />
                                                        网站制作最快只需1天 </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="span4 col-xm-6 col-xs-12 wow bounceInRight">
                                            <div class="platform_advantage_list">
                                                <div class="platform_advantage_img"> <img src="/template/pc/index/images/010.png" alt="响应式自助建站" /> </div>
                                                <div class="platform_advantage_brief">
                                                    <div class="brief_title">多合一终端使用</div>
                                                    <div class="brief_text"> 一个网站能够在CP+平板+手机<br />
                                                        完美响应展示。 </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="span4 col-xm-6 col-xs-12 wow bounceInLeft">
                                            <div class="platform_advantage_list">
                                                <div class="platform_advantage_img"> <img src="/template/pc/index/images/011.png" alt="响应式网站定制" /> </div>
                                                <div class="platform_advantage_brief">
                                                    <div class="brief_title">大数据</div>
                                                    <div class="brief_text"> 升级更新数据保留，企业数据沉淀<br />
                                                        实现数据分析。 </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="span4 col-xm-6 col-xs-12 wow bounceIn">
                                            <div class="platform_advantage_list">
                                                <div class="platform_advantage_img"> <img src="/template/pc/index/images/012.png" alt="html5建站平台" /> </div>
                                                <div class="platform_advantage_brief">
                                                    <div class="brief_title">高端设计</div>
                                                    <div class="brief_text"> 主流设计风格，极致交互体验，<br />
                                                        提升品牌价值 </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="span4 col-xm-6 col-xs-12 wow bounceInRight">
                                            <div class="platform_advantage_list">
                                                <div class="platform_advantage_img"> <img src="/template/pc/index/images/013.png" alt="H5响应式网站建设" /> </div>
                                                <div class="platform_advantage_brief">
                                                    <div class="brief_title">安全稳定</div>
                                                    <div class="brief_text"> 平台运行于阿里云计算中心<br />
                                                        多备份容灾保障，安全稳定 </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="rowFluid">
                                <div class="waves_box">
                                    <canvas id="waves" class="waves"></canvas>
                                </div>
                            </div>
                            <div class="container">
                                <div class="rowFluid">
                                    <div class="response_shows">
                                        <div class="response_shows_box wow bounceIn">
                                            <div class="response_shows_width">
                                                <div class="pc"> <img src="/template/pc/index/images/015.png" alt="建站神器" />
                                                    <div class="pic">
                                                        <div class="item"> <img src="/template/pc/index/images/0511.jpg" alt="快速响应式网站制作" /> </div>
                                                        <div class="item"> <img src="/template/pc/index/images/0512.jpg" alt="网站建设" /> </div>
                                                        <div class="item"> <img src="/template/pc/index/images/0513.jpg" alt="响应式自助建站" /> </div>
                                                    </div>
                                                </div>
                                                <div class="pad"> <img src="/template/pc/index/images/017.png" alt="H5响应式网站建设" />
                                                    <div class="pic">
                                                        <div class="item"> <img src="/template/pc/index/images/0521.jpg" alt="郑州数立方建站" /> </div>
                                                        <div class="item"> <img src="/template/pc/index/images/0522.jpg" alt="生态级响应式2.0建站平台" /> </div>
                                                        <div class="item"> <img src="/template/pc/index/images/0523.jpg" alt="H5响应式网站建设" /> </div>
                                                    </div>
                                                </div>
                                                <div class="phone"> <img src="/template/pc/index/images/016.png" alt="响应式网站模板" />
                                                    <div class="pic">
                                                        <div class="item"> <img src="/template/pc/index/images/0531.jpg" alt="响应式网站设计案例" /> </div>
                                                        <div class="item"> <img src="/template/pc/index/images/0532.jpg" alt="响应式网站案例" /> </div>
                                                        <div class="item"> <img src="/template/pc/index/images/0533.jpg" alt="html5建站平台" /> </div>
                                                    </div>
                                                </div>
                                                <div class="thumb"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="marketing_advantage">
                    <div class="rowFluid">
                        <div class="span12">
                            <div class="container">
                                <div class="all_title2 wow fadeInUp">
                                    <h3 class="title">营销优势</h3>
                                    <div class="text">MARKETING ADVANTAGE</div>
                                </div>
                                <div class="rowFluid">
                                    <div class="marketing_advantage_content">
                                        <div class="span3 col-sm-6 wow flipInY">
                                            <div class="marketing_advantage_list"> <img src="/template/pc/index/images/019.jpg" alt="响应式跨屏营销网站" /> </div>
                                        </div>
                                        <div class="span3 col-sm-6">
                                            <div class="span12 wow flipInY">
                                                <div class="marketing_advantage_list"> <img src="/template/pc/index/images/054.jpg" />
                                                    <div class="marketing_advantage_brief">
                                                        <div class="brief_title">全网营销<span><img src="/template/pc/index/images/020.png" alt="响应式网站营销" /></span></div>
                                                        <div class="brief_text">响应式全屏幕营销网站，无需重复投资无需重复维护，无需重复运营</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="span12 wow flipInY">
                                                <div class="marketing_advantage_list"> <img src="/template/pc/index/images/054.jpg" />
                                                    <div class="marketing_advantage_brief">
                                                        <div class="brief_title">优化搜索<span><img src="/template/pc/index/images/023.png" alt="响应式网站SEO" /></span></div>
                                                        <div class="brief_text">SEO轻松提高百度谷歌等搜索引擎的关键词自然排名。</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="span3 col-sm-6">
                                            <div class="span12 wow flipInY">
                                                <div class="marketing_advantage_list"> <img src="/template/pc/index/images/054.jpg" />
                                                    <div class="marketing_advantage_brief">
                                                        <div class="brief_title">微信无缝对接<span><img src="/template/pc/index/images/021.png" alt="平台微信营销" /></span></div>
                                                        <div class="brief_text">全面整合微信营销，数据对接微信互动与分享</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="span12 wow flipInY">
                                                <div class="marketing_advantage_list"> <img src="/template/pc/index/images/054.jpg" />
                                                    <div class="marketing_advantage_brief">
                                                        <div class="brief_title">二维码<span><img src="/template/pc/index/images/024.png" alt="二维码分享" /></span></div>
                                                        <div class="brief_text">生成页面二维码，任意分享</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="span3 col-sm-6">
                                            <div class="span12 wow flipInY">
                                                <div class="marketing_advantage_list"> <img src="/template/pc/index/images/054.jpg" />
                                                    <div class="marketing_advantage_brief">
                                                        <div class="brief_title">社交分享<span><img src="/template/pc/index/images/022.png" alt="跨屏网站社交分享" /></span></div>
                                                        <div class="brief_text">一键分享到微博、QQ空间朋友圈等社交网络</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="span12 wow flipInY">
                                                <div class="marketing_advantage_list"> <img src="/template/pc/index/images/054.jpg" />
                                                    <div class="marketing_advantage_brief">
                                                        <div class="brief_title">分销体系<span><img src="/template/pc/index/images/025.png" alt="响应式分销商城网站" /></span></div>
                                                        <div class="brief_text">系统化整合客户快速营销</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="partners">
                    <div class="rowFluid">
                        <div class="span12">
                            <div class="container">
                                <div class="all_title1 wow fadeInUp">
                                    <h3 class="title">合作伙伴</h3>
                                    <div class="text">COOPERATIVE PARTNER</div>
                                </div>
                                <div class="rowFluid">
                                    <div class="partners_content">
                                        <?php $data = db("links")->where("type",2)->limit(10)->order("sort","desc")->select(); foreach($data as $k=>$links): ?>
                                            <a href="<?php echo $links['url']; ?>" class="partners_content_list wow fadeInUp" data-wow-delay="0.2s" target="_blank">
                                                <img src="<?php echo $links['pic']; ?>" alt="<?php echo $links['title']; ?>" />
                                            </a>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="join_in">
                    <div class="rowFluid">
                        <div class="span12">
                            <div class="container">
                                <div class="join_in_title wow fadeInUp">选择壹恩建站，<span>让你的企业快速迈向互联网+时代</span></div>
                                <div class="join_in_text wow fadeInLeft">选择对的服务商能让您更快更好的迈进互联网+时代</div>
                                <a href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" class="all_button join_in_button wow fadeInUp" target="_blank">点击咨询</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="news_center">
                    <div class="rowFluid">
                        <div class="span12">
                            <div class="container">
                                <div class="all_title1 wow fadeInUp">
                                    <h3 class="title">新闻中心</h3>
                                    <div class="text">NEWS TRENDS</div>
                                </div>
                                <div class="rowFluid">
                                    <div class="news_center_content">
                                        <div class="span4 col-sm-12 wow fadeInDown" data-wow-delay="1.2s">
                                            <div class="news_center_list">
                                                <div class="news_center_list_img"> <img src="/template/pc/index/images/034.jpg" alt="云平台动态" /> </div>
                                                <div class="news_center_list_title">平台动态</div>
                                                <ul>
                                                    <?php $nav = db("nav")->where("id",8)->find();$model = db("models")->where("id",$nav["model"])->find();$table = "new_".$model["bname"];$res = db("nav")->where("id",8)->select();$navids = numbernav($res);$data = db("content")->where("pid","in",$navids)->where("reco","in","0,1")->limit(5)->order("create_Time desc")->select();$address = input("title");$etitle = explode("_",$address);if(count($etitle)==2): $address = $etitle[0]; endif; foreach($data as $k=>$list): $dq = db("address")->where("etitle",$address)->find();if($dq): $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["title"]=$dq["title"].$list["title"];$list["url"] = "/show/".$dq["etitle"]."_".$nav["url_static"]."/".$list["id"].".html";else: $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["url"] = "/".$nav["url_static"]."/".$list["id"].".html";endif; ?>
                                                        <li class="span12"> <a href="<?php echo $list['url']; ?>" class="span8" title="<?php echo $list['title']; ?>">
                                                            <i class="fa fa-angle-right"></i><?php echo $list['title']; ?></a>
                                                            <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;"><?php echo date('Y-m-d',$list['create_Time']); ?></div>
                                                        </li>
                                                    <?php endforeach; ?>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="span4 col-sm-12 wow fadeInUp" data-wow-delay="0.7s">
                                            <div class="news_center_list">
                                                <div class="news_center_list_img"> <img src="/template/pc/index/images/035.jpg" /> </div>
                                                <div class="news_center_list_title">帮助中心</div>
                                                <ul>
                                                    <?php $nav = db("nav")->where("id",9)->find();$model = db("models")->where("id",$nav["model"])->find();$table = "new_".$model["bname"];$res = db("nav")->where("id",9)->select();$navids = numbernav($res);$data = db("content")->where("pid","in",$navids)->where("reco","in","0,1")->limit(5)->order("create_Time desc")->select();$address = input("title");$etitle = explode("_",$address);if(count($etitle)==2): $address = $etitle[0]; endif; foreach($data as $k=>$list): $dq = db("address")->where("etitle",$address)->find();if($dq): $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["title"]=$dq["title"].$list["title"];$list["url"] = "/show/".$dq["etitle"]."_".$nav["url_static"]."/".$list["id"].".html";else: $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["url"] = "/".$nav["url_static"]."/".$list["id"].".html";endif; ?>
                                                    <li class="span12"> <a href="<?php echo $list['url']; ?>" class="span8" title="<?php echo $list['title']; ?>">
                                                        <i class="fa fa-angle-right"></i><?php echo $list['title']; ?></a>
                                                        <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;"><?php echo date('Y-m-d',$list['create_Time']); ?></div>
                                                    </li>
                                                    <?php endforeach; ?>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="span4 col-sm-12 wow fadeInDown" data-wow-delay="1.3s">
                                            <div class="news_center_list">
                                                <div class="news_center_list_img"> <img src="/template/pc/index/images/036.jpg" /> </div>
                                                <div class="news_center_list_title">行业资讯</div>
                                                <ul>
                                                    <?php $nav = db("nav")->where("id",10)->find();$model = db("models")->where("id",$nav["model"])->find();$table = "new_".$model["bname"];$res = db("nav")->where("id",10)->select();$navids = numbernav($res);$data = db("content")->where("pid","in",$navids)->where("reco","in","0,1")->limit(5)->order("create_Time desc")->select();$address = input("title");$etitle = explode("_",$address);if(count($etitle)==2): $address = $etitle[0]; endif; foreach($data as $k=>$list): $dq = db("address")->where("etitle",$address)->find();if($dq): $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["title"]=$dq["title"].$list["title"];$list["url"] = "/show/".$dq["etitle"]."_".$nav["url_static"]."/".$list["id"].".html";else: $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["url"] = "/".$nav["url_static"]."/".$list["id"].".html";endif; ?>
                                                    <li class="span12"> <a href="<?php echo $list['url']; ?>" class="span8" title="<?php echo $list['title']; ?>">
                                                        <i class="fa fa-angle-right"></i><?php echo $list['title']; ?></a>
                                                        <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;"><?php echo date('Y-m-d',$list['create_Time']); ?></div>
                                                    </li>
                                                    <?php endforeach; ?>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <script src="/template/pc/index/js/effects.js"></script>
                <div class="footer wow fadeInUp">
    <div class="rowFluid">
        <div class="span12">
            <div class="container">
                <div class="footer_content">
                    <div class="span4 col-xm-12">
                        <div class="footer_list">
                            <div class="span6">
                                <div class="bottom_logo">
                                    <div class="quick_navigation_title" >微信咨询</div>
                                    <img src="/uploads/20191010/346e58fb4bde47d97ee40b4ae1ba178b.png" alt="">
                                    <div style="text-align: center;width:100px;color:#fff;padding:10px 0">网站制作</div>
                                    <img src="/uploads/20191010/138d362daac263d66218901b7478c6f7.jpg" alt="">
                                    <div style="text-align: center;width:100px;color:#fff;padding:10px 0">设计咨询</div>
                                </div>
                            </div>

                            <div class="span6 col-xm-12">
                                <div class="quick_navigation">
                                    <div class="quick_navigation_title">快速导航</div>
                                    <ul>
                                        <li> <a href="/" title="首页">首页</a> </li>
                                        <?php $data = db("nav")->where("pid",0)->where("show",1)->limit(10)->order("sort","asc")->select();$address = input("title");$etitle = explode("_",$address); foreach($data as $k=>$nav): if(count($etitle)==2): $address = $etitle[0]; endif; $dq = db("address")->where("etitle",$address)->find(); if(($dq)): $nav["name"]=$dq["title"].$nav["name"]; $nav["url"]="/navs/".$dq["etitle"]."_".$nav["url_static"].".html"; else: $nav["url"]="/".$nav["url_static"].".html"; endif; ?>
                                            <li> <a href="<?php echo $nav['url']; ?>" title="<?php echo $nav['name']; ?>"><?php echo $nav['name']; ?></a> </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="span4 col-xm-6 col-xs-12">
                        <div class="footer_list">
                            <div class="footer_link">
                                <div class="footer_link_title">友情链接</div>
                                <ul id="frientLinks">
                                    <?php $data = db("links")->where("type",1)->limit(10)->order("sort","desc")->select(); foreach($data as $k=>$links): ?>
                                        <li><a href='<?php echo $links['url']; ?>' target='_blank'><?php echo $links['title']; ?></a> </li>
                                    <?php endforeach; ?>
                                    <div style="clear: both"></div>
                                </ul>
                                <div class="footer_link_title" style="margin-top: 20px">地区分站</div>
                                <ul>
                                    <?php if(($title)): $pid = db("address")->where("etitle",$title)->find();$data = db("address")->where("pid",$pid["id"])->select();if((!$data)): $data = db("address")->where("pid",$pid["pid"])->select();endif; else: $data = db("address")->where("static",1)->where("pid",0)->select();endif; foreach($data as $k=>$address): $address["url"]="/address/".$address["etitle"].".html"; ?>
                                        <li><a href='<?php echo $address['url']; ?>' target='_blank'><?php echo $address['title']; ?></a> </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="span4 col-xm-6 col-xs-12">
                        <div class="footer_list">
                            <div class="footer_cotact">
                                <div class="footer_cotact_title">联系方式</div>
                                <ul>
                                    <li><span class="footer_cotact_type">地址：</span><span class="footer_cotact_content">重庆市渝北区龙溪街道金龙路</span></li>
                                    <li><span class="footer_cotact_type">电话：</span><span class="footer_cotact_content"><a href="tel:17620917002" class="call">17620917002</a></span></li>
                                    <li><span class="footer_cotact_type">网址：</span><span class="footer_cotact_content"><a href="#" title="官网">www.dearests.cn</a></span></li>
                                    <li><span class="footer_cotact_type">邮箱：</span><span class="footer_cotact_content">425158482@qq.com</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright"> <yunu:config name="site_copyright" /></div>
        </div>
    </div>
</div>
            </div>
        </div>
    </div>
</div>

</body>
<!--<script src="/template/pc/index/js/online.js" type="text/javascript"></script>-->
</html>
