<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:64:"D:\phpstudy_pro\WWW\dearest.cn\/template/pc/index\list_jzfa.html";i:1570684303;s:67:"D:\phpstudy_pro\WWW\dearest.cn\template\pc\index\public_header.html";i:1570680120;s:67:"D:\phpstudy_pro\WWW\dearest.cn\template\pc\index\public_footer.html";i:1570679555;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="format-detection" content="telephone=yes">
    <title><?php $navcon = db("nav")->where("id",$navid)->find();$address = input("title");$etitle = explode("_",$address); if(count($etitle)==2): $address = $etitle[0]; endif; $dq = db("address")->where("etitle",$address)->find(); if($dq): $navcon["name"]=$dq["title"].$navcon["name"]; $navcon["url"]="/navs/".$dq["etitle"]."_".$navcon["url_static"].".html"; else: $navcon["url"]="/".$navcon["url_static"].".html"; endif; ?><?php echo $navcon['name']; ?> - <?php $fileadd = CONF_PATH.DS."extra".DS."site.php"; \think\Config::load($fileadd, "", "site"); $titlew = input("title"); $etitle = explode("_",$titlew); if(($titlew)): if(count($etitle)==2): $titles = $etitle[0]; $configarr = \think\Config::get("f_seo_title","site"); $address = db("address")->where("etitle",$titles)->find(); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $titles = $title; $address = db("address")->where("etitle",$titles)->find(); if(($address)): $configarr = \think\Config::get("f_seo_title","site"); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $configarr = \think\Config::get("seo_title","site"); ?><?php echo $configarr; endif; endif; else: $configarr = \think\Config::get("seo_title","site"); ?><?php echo $configarr; endif; ?></title>
    <meta name="keywords" content="<?php $fileadd = CONF_PATH.DS."extra".DS."site.php"; \think\Config::load($fileadd, "", "site"); $titlew = input("title"); $etitle = explode("_",$titlew); if(($titlew)): if(count($etitle)==2): $titles = $etitle[0]; $configarr = \think\Config::get("f_seo_keywords","site"); $address = db("address")->where("etitle",$titles)->find(); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $titles = $title; $address = db("address")->where("etitle",$titles)->find(); if(($address)): $configarr = \think\Config::get("f_seo_keywords","site"); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $configarr = \think\Config::get("seo_keywords","site"); ?><?php echo $configarr; endif; endif; else: $configarr = \think\Config::get("seo_keywords","site"); ?><?php echo $configarr; endif; ?>">
    <meta name="description" content="<?php $fileadd = CONF_PATH.DS."extra".DS."site.php"; \think\Config::load($fileadd, "", "site"); $titlew = input("title"); $etitle = explode("_",$titlew); if(($titlew)): if(count($etitle)==2): $titles = $etitle[0]; $configarr = \think\Config::get("f_seo_description","site"); $address = db("address")->where("etitle",$titles)->find(); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $titles = $title; $address = db("address")->where("etitle",$titles)->find(); if(($address)): $configarr = \think\Config::get("f_seo_description","site"); ?><?php echo str_replace("[address]",$address["title"],$configarr); else: $configarr = \think\Config::get("seo_description","site"); ?><?php echo $configarr; endif; endif; else: $configarr = \think\Config::get("seo_description","site"); ?><?php echo $configarr; endif; ?>">
    <meta name="renderer" content="webkit">
    <link rel="stylesheet" type="text/css" href="/template/pc/index/css/base.css"/>
    <link rel="stylesheet" type="text/css" href="/template/pc/index/css/animate.min.css"/>
    <link rel="stylesheet" type="text/css" href="/template/pc/index/css/owl.carousel.css"/>
    <link rel="stylesheet" type="text/css" href="/template/pc/index/css/style.css"/>
    <link rel="stylesheet" type="text/css" href="/template/pc/index/css/responsive.css"/>

    <script src="/template/pc/index/js/jquery-1.11.0.min.js"></script>
    <script src="/template/pc/index/js/wow.min_1.js"></script>
    <script src="/template/pc/index/js/owl.carousel.min.js"></script>
    <script src="/template/pc/index/js/page.js"></script>
</head>
<body>

<div class="header">
    <div class="rowFluid">
        <div class="span2 col-md-12">
            <div class="logo">
                <a href="/" title="返回首页">
                    <img src="/uploads/20191010/b2aad0e34b511de03d30f714cc11534f.png" alt="响应式网络建设设计公司网站模板(自适应移动设备)" />
                </a>
            </div>
        </div>
        <div class="span8">
            <div class="mobileMenuBtn"><span class="span1"></span><span class="span2"></span><span class="span3"></span></div>
            <div class="mobileMenuBtn_shad"></div>
            <div class="header_menu">
                <ul id="menu">
                    <?php $navid = isset($navid) ? $navid : 0;  $topnav = isset($topnav) ? $topnav : 0;  ?>
                    <li><a href="/"  <?php if(($navid==0)): ?>class="active"<?php endif; ?> title="首页">首页</a></li>
                    <?php $data = db("nav")->where("pid",0)->where("show",1)->limit(10)->order("sort","asc")->select();$address = input("title");$etitle = explode("_",$address); foreach($data as $k=>$nav): if(count($etitle)==2): $address = $etitle[0]; endif; $dq = db("address")->where("etitle",$address)->find(); if(($dq)): $nav["name"]=$dq["title"].$nav["name"]; $nav["url"]="/navs/".$dq["etitle"]."_".$nav["url_static"].".html"; else: $nav["url"]="/".$nav["url_static"].".html"; endif; ?>
                        <li><a href="<?php echo $nav['url']; ?>" <?php if($navid==$nav["id"]||$topnav==$nav['id']): ?>class="active"<?php endif; ?> title="<?php echo $nav['name']; ?>"><?php echo $nav['name']; ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <div class="span2"> </div>
    </div>
</div>
<div class="aside">
    <ul>
        <li class="consulting"> <a href="#this"  title="合作"><img src="/template/pc/index/images/057.png" alt="合作" />合作</a> </li>
        <li class="consulting">
            <a href="#this" title="建站在线客服">
                <span></span>
                <span></span>
                <span></span>
                <img src="/template/pc/index/images/059.png" class="img1" alt="建站在线客服" />
                <img src="/template/pc/index/images/061.png" class="img2" alt="建站在线客服" />咨询
            </a>
        </li>
        <li >
            <yunu:type typeid='92'>
                <a href="">
                    <img src="/template/pc/index/images/060.png" alt="建站帮助中心" />帮助
                </a>
            </yunu:type>
        </li>
    </ul>
</div>
<!--yinchang-->
<div class="consulting_box">
    <div class="title">
        <div class="title_t1">RELATEED CONSULTING</div>
        <div class="title_t2">相关咨询 </div>
    </div>
    <div class="consulting_type">
        <div class="consulting_type_title">选择下列产品马上在线沟通</div>
        <ul>
            <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" title="响应式建站咨询"> <img src="/template/pc/index/images/062.png" class="img1" alt="网站建设" /><img src="/template/pc/index/images/063.png" class="img2" alt="响应式网站咨询" />建站咨询 </a> </li>
            <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" title="建站平台加盟咨询"> <img src="/template/pc/index/images/062.png" class="img1" alt="建站平台" /><img src="/template/pc/index/images/063.png" class="img2" alt="建站平台代理咨询" />加盟咨询 </a> </li>
            <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=&site=qq&menu=yes" title="设计咨询"> <img src="/template/pc/index/images/062.png" class="img1" alt="设计咨询" /><img src="/template/pc/index/images/063.png" class="img2" alt="设计咨询" />设计咨询 </a> </li>
        </ul>
        <div class="time">服务时间：9:30-18:00</div>
    </div>
    <div class="problem">
        <div class="problem_title">你可能遇到了下面的问题</div>
        <ul>
            <?php $nav = db("nav")->where("id",10)->find();$model = db("models")->where("id",$nav["model"])->find();$table = "new_".$model["bname"];$res = db("nav")->where("id",10)->select();$navids = numbernav($res);$data = db("content")->where("pid","in",$navids)->where("reco","in","0,1")->limit(5)->order("create_Time desc")->select();$address = input("title");$etitle = explode("_",$address);if(count($etitle)==2): $address = $etitle[0]; endif; foreach($data as $k=>$list): $dq = db("address")->where("etitle",$address)->find();if($dq): $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["title"]=$dq["title"].$list["title"];$list["url"] = "/show/".$dq["etitle"]."_".$nav["url_static"]."/".$list["id"].".html";else: $list["content"] = db($table)->where("id",$list["content_id"])->find();$list["url"] = "/".$nav["url_static"]."/".$list["id"].".html";endif; ?>
                <li><span></span><a href="<?php echo $list['url']; ?>" title="<?php echo $list['title']; ?>"><?php echo $list['title']; ?></a></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <div class="close"> <img src="/template/pc/index/images/close.png" alt="关闭右侧工具栏" /> </div>
</div>
<div class="page">
    <div class="rowFluid">
        <div class="span12">
            <div class="main">
                <div class="page">
                    <div class="rowFluid">
                        <div class="span12">
                            <div class="main">
                                <div class="z_banner">
                                    <div class="rowFluid">
                                        <div class="span12">
                                            <div class="container">
                                                <h3 class="z_banner_title">
                                                    <?php $navcon = db("nav")->where("id",$navid)->find();$address = input("title");$etitle = explode("_",$address); if(count($etitle)==2): $address = $etitle[0]; endif; $dq = db("address")->where("etitle",$address)->find(); if($dq): $navcon["name"]=$dq["title"].$navcon["name"]; $navcon["url"]="/navs/".$dq["etitle"]."_".$navcon["url_static"].".html"; else: $navcon["url"]="/".$navcon["url_static"].".html"; endif; ?><?php echo $navcon['name']; ?>
                                                </h3>
                                                <div class="z_banner_text">
                                                    <?php $navcon = db("nav")->where("id",$navid)->find();$address = input("title");$etitle = explode("_",$address); if(count($etitle)==2): $address = $etitle[0]; endif; $dq = db("address")->where("etitle",$address)->find(); if($dq): $navcon["name"]=$dq["title"].$navcon["name"]; $navcon["url"]="/navs/".$dq["etitle"]."_".$navcon["url_static"].".html"; else: $navcon["url"]="/".$navcon["url_static"].".html"; endif; ?><?php echo $navcon['cname']; ?>
                                                </div>
                                                <div class="rowFluid">
                                                    <div class="span12">
                                                        <div class="web_tip">
                                                            <h4>选好模板记录编号联系客服</h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <ul class="platform_advantage_bg_z">
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <div class="section" style="padding-bottom: 0;">
                                    <div class="container">
                                        <div class="section-title text-center"><h3>网站建设价格表</h3></div>
                                        <div class="price-table clearfix">
                                            <div class="text-center hidden-sm hidden-xs">
                                                <div class="pricing__title">
                                                    <div class="right">
                                                        <div>精品型</div>
                                                        <div>¥5888+</div>
                                                    </div>
                                                    <div class="right">
                                                        <div>标准型</div>
                                                        <div>¥3888</div>
                                                    </div>
                                                    <div class="right">
                                                        <div>基础型</div>
                                                        <div>¥2888</div>
                                                    </div>
                                                    <div style="clear: both"></div>
                                                </div>
                                                <ul>
                                                    <li> 
                                                        <span>域名 / 主机</span>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                    </li>
                                                    <li> <span>图片处理 / 首页设计</span>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                    </li>
                                                    <li> <span>网页设计制作</span>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                    </li>
                                                    <li> <span>基础SEO优化设置</span>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                    </li>
                                                    <li> <span>基础数据录入</span>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                    </li>
                                                    <li> <span>后台操作指导</span>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                    </li>
                                                    <li> <span>售后服务支持</span>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                    </li>
                                                    <li> <span>手机触屏版</span>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/cuo.png)no-repeat center">&nbsp;</div>
                                                    </li>
                                                    <li> <span>地区分站</span>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/cuo.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/cuo.png)no-repeat center">&nbsp;</div>
                                                    </li>
                                                    <li> <span>赠送关键词排名</span>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/cuo.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/cuo.png)no-repeat center">&nbsp;</div>
                                                    </li>
                                                    <li> <span>精品个性化设计</span>
                                                        <div class="right" style="background: url(/template/pc/index/images/dui.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/cuo.png)no-repeat center">&nbsp;</div>
                                                        <div class="right" style="background: url(/template/pc/index/images/cuo.png)no-repeat center">&nbsp;</div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="template_show">
                                    <div class="rowFluid">
                                        <div class="span12">
                                            <div class="container">
                                                <div class="template_show_content" style="min-height: 0px;"> <div class="span6 col-xs-12 wow fadeInUp">
                                                    <div class="template_show_list_box">
                                                        <div class="template_show_list">
                                                            <div class="template_show-container">
                                                                <div class="template_show_list_pic"> <a class="front-model"> <img src="/template/pc/index/images/1-1610011634500-L.png" alt="女装网站"/> </a> </div>
                                                                <div class="template_show_list_text">
                                                                    <h3>女装网站</h3>
                                                                </div>
                                                                <div class="template_show_list_button"> <a href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" class="all_button " title="女装网站" target="_blank">创建网站</a> <a href="http://www.dede58.com" target="_blank" title="女装网站" class="all_button">预览网站</a> </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div><div class="span6 col-xs-12 wow fadeInUp">
                                                    <div class="template_show_list_box">
                                                        <div class="template_show_list">
                                                            <div class="template_show-container">
                                                                <div class="template_show_list_pic"> <a class="front-model"> <img src="/template/pc/index/images/1-1610011634200-L.png" alt="红木网站"/> </a> </div>
                                                                <div class="template_show_list_text">
                                                                    <h3>红木网站</h3>
                                                                </div>
                                                                <div class="template_show_list_button"> <a href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" class="all_button " title="红木网站" target="_blank">创建网站</a> <a href="http://www.dede58.com" target="_blank" title="红木网站" class="all_button">预览网站</a> </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div><div class="span6 col-xs-12 wow fadeInUp">
                                                    <div class="template_show_list_box">
                                                        <div class="template_show_list">
                                                            <div class="template_show-container">
                                                                <div class="template_show_list_pic"> <a class="front-model"> <img src="/template/pc/index/images/1-1610011634040-L.png" alt="集团网站"/> </a> </div>
                                                                <div class="template_show_list_text">
                                                                    <h3>集团网站</h3>
                                                                </div>
                                                                <div class="template_show_list_button"> <a href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" class="all_button " title="集团网站" target="_blank">创建网站</a> <a href="http://www.dede58.com" target="_blank" title="集团网站" class="all_button">预览网站</a> </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div><div class="span6 col-xs-12 wow fadeInUp">
                                                    <div class="template_show_list_box">
                                                        <div class="template_show_list">
                                                            <div class="template_show-container">
                                                                <div class="template_show_list_pic"> <a class="front-model"> <img src="/template/pc/index/images/1-1610011633480-L.png" alt="时尚家居网站"/> </a> </div>
                                                                <div class="template_show_list_text">
                                                                    <h3>时尚家居网站</h3>
                                                                </div>
                                                                <div class="template_show_list_button"> <a href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" class="all_button " title="时尚家居网站" target="_blank">创建网站</a> <a href="http://www.dede58.com" target="_blank" title="时尚家居网站" class="all_button">预览网站</a> </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div><div class="span6 col-xs-12 wow fadeInUp">
                                                    <div class="template_show_list_box">
                                                        <div class="template_show_list">
                                                            <div class="template_show-container">
                                                                <div class="template_show_list_pic"> <a class="front-model"> <img src="/template/pc/index/images/1-1610011600310-L.png" alt="互联网模板"/> </a> </div>
                                                                <div class="template_show_list_text">
                                                                    <h3>互联网模板</h3>
                                                                </div>
                                                                <div class="template_show_list_button"> <a href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" class="all_button " title="互联网模板" target="_blank">创建网站</a> <a href="http://www.dede58.com" target="_blank" title="互联网模板" class="all_button">预览网站</a> </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div><div class="span6 col-xs-12 wow fadeInUp">
                                                    <div class="template_show_list_box">
                                                        <div class="template_show_list">
                                                            <div class="template_show-container">
                                                                <div class="template_show_list_pic"> <a class="front-model"> <img src="/template/pc/index/images/1-1610011559280-L.png" alt="明星展示站"/> </a> </div>
                                                                <div class="template_show_list_text">
                                                                    <h3>明星展示站</h3>
                                                                </div>
                                                                <div class="template_show_list_button"> <a href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" class="all_button " title="明星展示站" target="_blank">创建网站</a> <a href="#" target="_blank" title="明星展示站" class="all_button">预览网站</a> </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> </div>
                                                <div class="rowFluid">
                                                    <div class="span12">
                                                        <div class="web_tip">
                                                            <h4>如果您想自己设计网站,戳这里</h4>
                                                            <div class="create_web">
                                                                <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" title="快速响应式网站定制">高级定制咨询</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="know_more wow fadeInUp">
                                                    <div class="know_more_text">了解更多建站服务或加盟事宜，敬请联系</div>
                                                    <a target="_blank" class="all_button" href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" title="响应式建站咨询">建站咨询</a>
                                                    <a target="_blank" class="all_button" href="http://wpa.qq.com/msgrd?v=3&uin=425158482&site=qq&menu=yes" title="建站平台加盟咨询">加盟咨询</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer wow fadeInUp">
    <div class="rowFluid">
        <div class="span12">
            <div class="container">
                <div class="footer_content">
                    <div class="span4 col-xm-12">
                        <div class="footer_list">
                            <div class="span6">
                                <div class="bottom_logo">
                                    <div class="quick_navigation_title" >微信咨询</div>
                                    <img src="/uploads/20191010/346e58fb4bde47d97ee40b4ae1ba178b.png" alt="">
                                    <div style="text-align: center;width:100px;color:#fff;padding:10px 0">网站制作</div>
                                    <img src="/uploads/20191010/138d362daac263d66218901b7478c6f7.jpg" alt="">
                                    <div style="text-align: center;width:100px;color:#fff;padding:10px 0">设计咨询</div>
                                </div>
                            </div>

                            <div class="span6 col-xm-12">
                                <div class="quick_navigation">
                                    <div class="quick_navigation_title">快速导航</div>
                                    <ul>
                                        <li> <a href="/" title="首页">首页</a> </li>
                                        <?php $data = db("nav")->where("pid",0)->where("show",1)->limit(10)->order("sort","asc")->select();$address = input("title");$etitle = explode("_",$address); foreach($data as $k=>$nav): if(count($etitle)==2): $address = $etitle[0]; endif; $dq = db("address")->where("etitle",$address)->find(); if(($dq)): $nav["name"]=$dq["title"].$nav["name"]; $nav["url"]="/navs/".$dq["etitle"]."_".$nav["url_static"].".html"; else: $nav["url"]="/".$nav["url_static"].".html"; endif; ?>
                                            <li> <a href="<?php echo $nav['url']; ?>" title="<?php echo $nav['name']; ?>"><?php echo $nav['name']; ?></a> </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="span4 col-xm-6 col-xs-12">
                        <div class="footer_list">
                            <div class="footer_link">
                                <div class="footer_link_title">友情链接</div>
                                <ul id="frientLinks">
                                    <?php $data = db("links")->where("type",1)->limit(10)->order("sort","desc")->select(); foreach($data as $k=>$links): ?>
                                        <li><a href='<?php echo $links['url']; ?>' target='_blank'><?php echo $links['title']; ?></a> </li>
                                    <?php endforeach; ?>
                                    <div style="clear: both"></div>
                                </ul>
                                <div class="footer_link_title" style="margin-top: 20px">地区分站</div>
                                <ul>
                                    <?php if(($title)): $pid = db("address")->where("etitle",$title)->find();$data = db("address")->where("pid",$pid["id"])->select();if((!$data)): $data = db("address")->where("pid",$pid["pid"])->select();endif; else: $data = db("address")->where("static",1)->where("pid",0)->select();endif; foreach($data as $k=>$address): $address["url"]="/address/".$address["etitle"].".html"; ?>
                                        <li><a href='<?php echo $address['url']; ?>' target='_blank'><?php echo $address['title']; ?></a> </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="span4 col-xm-6 col-xs-12">
                        <div class="footer_list">
                            <div class="footer_cotact">
                                <div class="footer_cotact_title">联系方式</div>
                                <ul>
                                    <li><span class="footer_cotact_type">地址：</span><span class="footer_cotact_content">重庆市渝北区龙溪街道金龙路</span></li>
                                    <li><span class="footer_cotact_type">电话：</span><span class="footer_cotact_content"><a href="tel:17620917002" class="call">17620917002</a></span></li>
                                    <li><span class="footer_cotact_type">网址：</span><span class="footer_cotact_content"><a href="#" title="官网">www.dearests.cn</a></span></li>
                                    <li><span class="footer_cotact_type">邮箱：</span><span class="footer_cotact_content">425158482@qq.com</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright"> <yunu:config name="site_copyright" /></div>
        </div>
    </div>
</div>
            </div>
        </div>
    </div>
</div>
</body>
<script src="#templets/default/js/online.js" type="text/javascript"></script>
</html>
