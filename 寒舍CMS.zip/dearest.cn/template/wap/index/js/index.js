//banner
var swiper1 = new Swiper('.banner', {
    autoHeight: true, //enable auto height
    spaceBetween: 0,
    effect : 'flip',
    loop: true,
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
});
//产品
var galleryThumbs = new Swiper('.gallery-thumbs', {
    spaceBetween: 0,
    slidesPerView: "auto",
    freeMode: true,
    loopedSlides: 5, //looped slides should be the same
    watchSlidesVisibility: true,
    watchSlidesProgress: true,
});
var galleryTop = new Swiper('.gallery-top', {
    spaceBetween: 0,
    loopedSlides: 5, //looped slides should be the same
    thumbs: {
        swiper: galleryThumbs,
    },
});
//案例滚动
var swiper2 = new Swiper('.anli_box', {
    slidesPerView: "auto",
    spaceBetween: 20,
});
//优势滚动
var swiper3 = new Swiper('.ys_box', {
    slidesPerView: "auto",
    spaceBetween: 20,

    loop: true,
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
});
//荣誉滚动
var swiper4 = new Swiper('.ry_box', {
    slidesPerView: "auto",
    spaceBetween: 2,
});
//合作伙伴
var swiper5 = new Swiper('.hb_box', {
    slidesPerView: "auto",
    spaceBetween: 10,
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
});